package testing;

import java.util.ArrayList;
import java.util.List;

import domain.Customer;
import domain.Destination;
import domain.Item;
import domain.Order;
import junit.framework.TestCase;

public class DeliveryStationTest extends TestCase {

	public void testDeliveryStation() {
		// Making an order
		Customer c1 = new Customer("Geronimo", "5857548778");
		Destination d1 = Destination.RIT;
		List<Item> itemList = new ArrayList<Item>() {
			{
				add(new Item("Pizza", 5, 5, 10, 4));
				add(new Item("Pizza Logs", 5, 0, 6, 4));
			}
		};
		Order order1 = new Order(itemList, c1, d1);

		// Using Order order1 to construct DeliveryStationTest

	
	}

}
