package testing;

import junit.framework.TestCase;

public class LimitedJobScheduleTest extends TestCase {

	/**
	 * Forcing ticks 
	 */
	public void testLimitedJobSchedule() {
		//Creating Orders 
		/**
		 * 
		
		Customer c1 = new Customer("Geronimo", "5857548778");
		Destination d1 = new Destination("RIT", 15, 5);
		List<Item> itemList = new ArrayList<Item>() {
			{
				add(new Item("Pizza", 5, 10, 4));
				
			}
		};
		Order order1 = new Order(itemList, c1, d1);
		//New restaurant with 1cook, 1 oven (space=10), and one deliverer
		OrderTracker ot1 = new OrderTracker(1,1,10,1); 
		ot1.startDay();
		//Day has started. Only one order will be processed
		assertEquals(ot1.isDayStart, true); //Testing if ticker has begun
		
		//Submiting single item order: Pizza with integers > 0 for all values
		ot1.submitToKitchen(order1); 
		
		 */
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}