package testing;

import junit.framework.TestCase;

public class KitchenStationTest extends TestCase {

	public void testKitchenStation() {
		fail("Not yet implemented");
	}

}
