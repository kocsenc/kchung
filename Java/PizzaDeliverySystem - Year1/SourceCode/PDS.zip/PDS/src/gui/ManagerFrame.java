/*
 * ManagerPass.java
 *
 * Created on __DATE__, __TIME__
 */

package gui;

import java.awt.Frame;
import java.io.IOException;
import java.util.Arrays;

import javax.swing.JDialog;

import data.OrderTracker;
import data.PasswordTracker;
import data.StatisticsTracker;

/**
 * Generates a manager window for manager report functions.
 * 
 * @author kxc4519
 */
public class ManagerFrame extends javax.swing.JFrame {

	/** Creates new form ManagerPass */
	public ManagerFrame() {
		initComponents();
		this.setLocationRelativeTo(null);
		quitDialog.setLocationRelativeTo(null);

	}

	// GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		quitDialog = new javax.swing.JDialog();
		jPanel1 = new javax.swing.JPanel();
		jPanel2 = new javax.swing.JPanel();
		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jPanel3 = new javax.swing.JPanel();
		quitDialogQuit = new javax.swing.JButton();
		quitDialogBack = new javax.swing.JButton();
		GenerateReports = new javax.swing.JButton();
		EndDay = new javax.swing.JButton();
		closeButton = new javax.swing.JButton();
		editPasswordButton = new javax.swing.JButton();

		quitDialog.setTitle("Are you sure?");
		quitDialog.setAlwaysOnTop(true);
		quitDialog.setMinimumSize(new java.awt.Dimension(550, 300));
		quitDialog.setModal(true);

		jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24));
		jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/Icons/onebit_36.png"))); // NOI18N
		jLabel1.setText("Are you sure you want to end the day? ");

		jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18));
		jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel2.setText("All currently processing orders will be cancelled!");

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel2Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																jLabel2,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																502,
																Short.MAX_VALUE)
														.addComponent(
																jLabel1,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																502,
																Short.MAX_VALUE))
										.addContainerGap()));
		jPanel2Layout
				.setVerticalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												jLabel1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												65,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel2,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												45, Short.MAX_VALUE)
										.addContainerGap()));

		quitDialogQuit.setFont(new java.awt.Font("Segoe UI", 0, 36));
		quitDialogQuit.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/onebit_26.png"))); // NOI18N
		quitDialogQuit.setText("Quit");
		quitDialogQuit.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				quitDialogQuitActionPerformed(evt);
			}
		});

		quitDialogBack.setFont(new java.awt.Font("Segoe UI", 0, 32));
		quitDialogBack.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/onebit_29.png"))); // NOI18N
		quitDialogBack.setText("Back");
		quitDialogBack.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				quitDialogBackActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(
				jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout
				.setHorizontalGroup(jPanel3Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel3Layout
										.createSequentialGroup()
										.addComponent(
												quitDialogBack,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												259,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												8, Short.MAX_VALUE)
										.addComponent(
												quitDialogQuit,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												259,
												javax.swing.GroupLayout.PREFERRED_SIZE)));
		jPanel3Layout.setVerticalGroup(jPanel3Layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(quitDialogBack,
						javax.swing.GroupLayout.DEFAULT_SIZE, 113,
						Short.MAX_VALUE)
				.addComponent(quitDialogQuit,
						javax.swing.GroupLayout.DEFAULT_SIZE, 113,
						Short.MAX_VALUE));

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				.addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addComponent(
												jPanel2,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jPanel3,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)));

		javax.swing.GroupLayout quitDialogLayout = new javax.swing.GroupLayout(
				quitDialog.getContentPane());
		quitDialog.getContentPane().setLayout(quitDialogLayout);
		quitDialogLayout.setHorizontalGroup(quitDialogLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						quitDialogLayout
								.createSequentialGroup()
								.addContainerGap()
								.addComponent(jPanel1,
										javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE).addContainerGap()));
		quitDialogLayout.setVerticalGroup(quitDialogLayout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				quitDialogLayout
						.createSequentialGroup()
						.addContainerGap()
						.addComponent(jPanel1,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE).addContainerGap()));

		setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
		setTitle("Manager Tools - Restricted for store manager only");
		setAlwaysOnTop(true);
		setResizable(false);

		GenerateReports.setFont(new java.awt.Font("Segoe UI", 0, 32));
		GenerateReports.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/onebit_39.png"))); // NOI18N
		GenerateReports.setText("Generate Reports");
		GenerateReports.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				GenerateReportsActionPerformed(evt);
			}
		});

		EndDay.setBackground(new java.awt.Color(229, 15, 15));
		EndDay.setFont(new java.awt.Font("Segoe UI", 0, 32));
		EndDay.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/Icons/onebit_49.png"))); // NOI18N
		EndDay.setText("End Day");
		EndDay.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				EndDayActionPerformed(evt);
			}
		});

		closeButton.setFont(new java.awt.Font("Segoe UI", 0, 32));
		closeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/Icons/onebit_33.png"))); // NOI18N
		closeButton.setText("Close");
		closeButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				closeButtonActionPerformed(evt);
			}
		});

		editPasswordButton.setFont(new java.awt.Font("Segoe UI", 0, 24));
		editPasswordButton.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/Manager Entry.png"))); // NOI18N
		editPasswordButton.setText("Edit Manager Password");
		editPasswordButton.setToolTipText("");
		editPasswordButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						editPasswordButtonActionPerformed(evt);
					}
				});

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						javax.swing.GroupLayout.Alignment.TRAILING,
						layout.createSequentialGroup()
								.addContainerGap()
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.TRAILING)
												.addComponent(
														editPasswordButton,
														javax.swing.GroupLayout.Alignment.LEADING,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														421, Short.MAX_VALUE)
												.addGroup(
														javax.swing.GroupLayout.Alignment.LEADING,
														layout.createSequentialGroup()
																.addComponent(
																		closeButton)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																.addComponent(
																		EndDay,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		246,
																		Short.MAX_VALUE))
												.addComponent(
														GenerateReports,
														javax.swing.GroupLayout.Alignment.LEADING,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														421, Short.MAX_VALUE))
								.addContainerGap()));
		layout.setVerticalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						layout.createSequentialGroup()
								.addContainerGap()
								.addComponent(editPasswordButton,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										91,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(GenerateReports,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										265,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(
														EndDay,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														140, Short.MAX_VALUE)
												.addComponent(
														closeButton,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														140, Short.MAX_VALUE))
								.addContainerGap()));

		pack();
	}// </editor-fold>
		// GEN-END:initComponents

	/**
	 * Launches the Dialog to change the manager password.
	 * 
	 * @param evt
	 */
	private void editPasswordButtonActionPerformed(
			java.awt.event.ActionEvent evt) {
		JDialog x = new ChangeManagerPasswordDialog(this, true);
		x.setVisible(true);
	}

	/**
	 * CLOSE MANAGER OPTIONS BUTTON Disposes the manager frame and brings you
	 * back to the main order frame.
	 * 
	 * @param evt
	 */
	private void closeButtonActionPerformed(java.awt.event.ActionEvent evt) {
		this.dispose();
	}

	/**
	 * END DAY BUTTON Launches a confirmation dialog.
	 * 
	 * @param evt
	 */
	private void EndDayActionPerformed(java.awt.event.ActionEvent evt) {
		quitDialog.setVisible(true);

	}

	// **************** Are you sure you want to quit? Dialog BEGIN***//
	/**
	 * DIALOG BACK BUTTON Closes confirmation dialog.
	 * 
	 * @param evt
	 */
	private void quitDialogBackActionPerformed(java.awt.event.ActionEvent evt) {
		quitDialog.dispose();
	}

	/**
	 * DIALOG QUIT BUTTON Actually stops the system, and diposes of all the
	 * windows ever created.
	 * 
	 * @param evt
	 */
	private void quitDialogQuitActionPerformed(java.awt.event.ActionEvent evt) {
		// End day button code here:
		quitDialog.dispose();
		this.setVisible(false);
		this.dispose();
		Frame[] pdsFrames = OrderFrame.getFrames();
		for (Frame i : pdsFrames) {
			i.setVisible(false);
			i.dispose();
		}
		data.Main.shutDown();
	}

	// close the main window.

	// **************** Are you sure you want to quit? Dialog END *******//

	/**
	 * GENERATE REPORTS BUTTON Button that will generate manager reports.
	 * 
	 * @param evt
	 */
	private void GenerateReportsActionPerformed(java.awt.event.ActionEvent evt) {
		JDialog x = new StatisticsDialog(this, true);
		x.setVisible(true);
	}

	// GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton EndDay;
	private javax.swing.JButton GenerateReports;
	private javax.swing.JButton closeButton;
	private javax.swing.JButton editPasswordButton;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JDialog quitDialog;
	private javax.swing.JButton quitDialogBack;
	private javax.swing.JButton quitDialogQuit;
	// End of variables declaration//GEN-END:variables

}