package gui;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;
import javax.swing.JWindow;

import data.ItemTracker;
import data.Main;
import data.OrderTracker;
import domain.Item;

/**
 * Generates a iFrame for start of day.
 * 
 * @author acc3863
 */
public class DayStartFrame extends javax.swing.JFrame {

	// Making Singleton
	private static DayStartFrame instance;

	static {
		instance = new DayStartFrame();
	}

	/** Creates new form DayStartFrame */
	public DayStartFrame() {
		// setUndecorated(true);
		// getRootPane().setWindowDecorationStyle(JRootPane.NONE);
		initComponents();
		// this.setIconImage(Toolkit.getDefaultToolkit().getImage("logo32.png"));
		this.setLocationRelativeTo(null);

	}

	// GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		editMenuButton = new javax.swing.JButton();
		editStoreButton = new javax.swing.JButton();
		startDayButton = new javax.swing.JButton();
		jButton1 = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
		setTitle("Start Day");
		setBounds(new java.awt.Rectangle(800, 200, 300, 700));
		setName("Start Day");
		setResizable(false);

		editMenuButton.setFont(new java.awt.Font("Segoe UI", 0, 36));
		editMenuButton.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/eEdit2.png"))); // NOI18N
		editMenuButton.setText("Edit Menu");
		editMenuButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				editMenuButtonActionPerformed(evt);
			}
		});

		editStoreButton.setFont(new java.awt.Font("Segoe UI", 0, 36));
		editStoreButton.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/Edit.png"))); // NOI18N
		editStoreButton.setText("Edit Store Capital");
		editStoreButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				editStoreButtonActionPerformed(evt);
			}
		});

		startDayButton.setFont(new java.awt.Font("Segoe UI", 0, 36));
		startDayButton.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/Check.png"))); // NOI18N
		startDayButton.setText("Start Day");
		startDayButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				startDayHandler(evt);
			}
		});

		jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/Icons/onebit_35.png"))); // NOI18N
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						layout.createSequentialGroup()
								.addContainerGap()
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.TRAILING)
												.addComponent(
														editMenuButton,
														javax.swing.GroupLayout.Alignment.LEADING,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														365, Short.MAX_VALUE)
												.addComponent(
														editStoreButton,
														javax.swing.GroupLayout.Alignment.LEADING,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														365, Short.MAX_VALUE)
												.addGroup(
														layout.createSequentialGroup()
																.addComponent(
																		jButton1,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		129,
																		Short.MAX_VALUE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(
																		startDayButton)))
								.addContainerGap()));
		layout.setVerticalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						layout.createSequentialGroup()
								.addContainerGap()
								.addComponent(editMenuButton,
										javax.swing.GroupLayout.DEFAULT_SIZE,
										150, Short.MAX_VALUE)
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(editStoreButton,
										javax.swing.GroupLayout.DEFAULT_SIZE,
										150, Short.MAX_VALUE)
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.TRAILING)
												.addComponent(
														jButton1,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														150, Short.MAX_VALUE)
												.addComponent(
														startDayButton,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														150, Short.MAX_VALUE))
								.addContainerGap()));

		pack();
	}// </editor-fold>
		// GEN-END:initComponents

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		this.dispose();
		Main.shutDown();
		System.exit(0);
	}

	/**
	 * Launches the Edit Store Capital frame.
	 * 
	 * @param evt
	 */
	protected void editStoreButtonActionPerformed(java.awt.event.ActionEvent evt) {
		JDialog editCapitalDialog = new EditCapitalDialog(this, true);
		editCapitalDialog.setVisible(true);

	}

	/**
	 * EDIT MENU BUTTON Launches the Edit Store Menu frame.
	 * 
	 * @param evt
	 */
	private void editMenuButtonActionPerformed(java.awt.event.ActionEvent evt) {
		JDialog editMenuDialog = new EditMenuDialog(this, true);
		editMenuDialog.setVisible(true);

	}

	/**
	 * START DAY BUTTON This method checks to make sure that all prerequisites
	 * to begin the day are met. These are: there is at least 1 item; no item
	 * surpasses the capacity of the ovens;the store capital has been set. If
	 * any of these conditionals are broken, the user is notified and cannot go
	 * through this frame. If not, the ticker starts and the store is officially
	 * running
	 * 
	 * @param evt
	 */
	private void startDayHandler(java.awt.event.ActionEvent evt) {
		// Start DAY
		// Start ticking
		if (OrderTracker.getInstance().isReadyToStart()
				&& (!ItemTracker.getInstance().getData().isEmpty())
				&& canAllItemsFit()) {
			JFrame orderFrame = new OrderFrame();
			orderFrame.setVisible(true);
			this.dispose(); // this.setVisible(false)???
			try {
				data.ItemTracker.getInstance().saveToFile();
			} catch (IOException e) {
				JOptionPane.showMessageDialog(this,
						"Error saving Items to file");
			}
			OrderTracker.getInstance().startDay();
		} else {
			if (!OrderTracker.getInstance().isReadyToStart()
					|| (ItemTracker.getInstance().getData().isEmpty())) {
				JOptionPane
						.showMessageDialog(this,
								"You must first set up your store's capital and have at least 1 item.");
			} else {
				JOptionPane.showMessageDialog(this,
						"Make sure your oven space can fit each item.");
			}
		}

	}

	/**
	 * Helper method to return a boolean depicting if the oven space is
	 * sufficient to meet space requirements for EACH item.
	 * 
	 * @return true - all items can indeed fit within the oven space parameters.
	 *         false otherwise.
	 */
	private boolean canAllItemsFit() {
		for (Item i : ItemTracker.getInstance().getData()) {
			// If item occupies more space than we have available
			if (i.getOvenSpace() > OrderTracker.getInstance().getOvenSpace()) {

				return false;
			}

		}
		return true;
	}

	/**
	 * Singleton for Start frame
	 * 
	 * @return - Instance of this Frame
	 */
	public static DayStartFrame getInstance() {
		return instance;
	}

	// GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton editMenuButton;
	private javax.swing.JButton editStoreButton;
	private javax.swing.JButton jButton1;
	private javax.swing.JButton startDayButton;
	// End of variables declaration//GEN-END:variables

}