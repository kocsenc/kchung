/**
 * 
 */
package gui.model;

import domain.Item.TSide;

/**
 * Java really should have tuples.
 * @author acc3863
 * 
 */
public class Tuple<K, V> {
	public K first;
	public V second;

	public Tuple(K fst, V snd) {
		this.first = fst;
		this.second = snd;
	}

	public String toString() {
		return first.toString() + "," + second.toString();
	}
}
