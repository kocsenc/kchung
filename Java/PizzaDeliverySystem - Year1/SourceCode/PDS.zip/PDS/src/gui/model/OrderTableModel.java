/**
 * 
 */
package gui.model;

import javax.swing.table.AbstractTableModel;

import data.OrderTracker;
import domain.Order;

/**
 * OrderTableModel implements a TableModel for Orders.
 * 
 * @author acc3863
 * 
 */
public class OrderTableModel extends AbstractTableModel {
	private static Class<?>[] columnClasses = new Class<?>[] {
			java.lang.Integer.class, java.lang.String.class,
			java.lang.String.class, java.lang.String.class,
			java.lang.String.class, java.lang.String.class,
			java.lang.String.class, java.lang.String.class };
	private static String[] columnNames = new String[] { "Order #", "Customer",
			"Destination", "Cost", "Time Placed", "Estimated Delivery",
			"Actual Delivery Time", "Status" };

	@Override
	public String getColumnName(int columnIndex) {
		return columnNames[columnIndex];
	}

	@Override
	public Class<?> getColumnClass(int columnIndex) {
		return columnClasses[columnIndex];
	}

	@Override
	public int getColumnCount() {
		return columnNames.length;
	}

	@Override
	public int getRowCount() {
		return OrderTracker.getInstance().getData().size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Order o = OrderTracker.getInstance().getData().get(rowIndex);
		switch (columnIndex) {
		case 0:
			return o.getId();
		case 1:
			return o.getCustomer().getName();
		case 2:
			return o.getDestination().getName();
		case 3:
			return o.getPriceString();
		case 4:
			return OrderTracker.formatTime(o.getTimePlaced());
		case 5:
			return OrderTracker.formatTime(o.getEstimate() + o.getTimePlaced());
		case 6:
			return o.getTimeDelivered() == -1 ? "N/A" : OrderTracker.formatTime(o.getTimeDelivered());
		case 7:
			return o.getStatus().getName();
		}
		return "BIG ERRORS WATCH OUT";
	}

}
