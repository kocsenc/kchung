package gui.model;

import javax.swing.table.AbstractTableModel;

import data.ItemTracker;
import domain.Item;
/**
 * Adds a table for menu items.
 * @author acc3863
 *
 */
public class DeleteableItemTableModel extends AbstractTableModel {
	private static Class<?>[] columnClasses = new Class<?>[] { String.class,
			String.class };
	private static String[] columnNames = new String[] { "Name", "Price" };
	
	/**
	 * Getter for length of columns.
	 */
	@Override
	public int getColumnCount() {
		return columnNames.length;
	}
	
	/**
	 * Getter for column name in table.
	 */
	@Override
	public String getColumnName(int columnIndex) {
		return columnNames[columnIndex];
	}
	
	/**
	 * getter for column class in table.
	 */
	@Override
	public Class<?> getColumnClass(int columnIndex) {
		return columnClasses[columnIndex];
	}
	
	/**
	 * getter for row count in table.
	 */
	@Override
	public int getRowCount() {
		return ItemTracker.getInstance().getData().size();
	}
	
	/**
	 * getter for value at a specific row and column index position.
	 */
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Item i = ItemTracker.getInstance().getData().get(rowIndex);
		if (columnIndex == 0) {
			return i.getName();
		} else if (columnIndex == 1) {
			return i.getPriceString();
		} else {
			throw new RuntimeException("Invalid column index in itemtable");
		}
	}
}
