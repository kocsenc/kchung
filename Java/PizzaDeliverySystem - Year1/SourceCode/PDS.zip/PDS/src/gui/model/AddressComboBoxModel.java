/**
 * 
 */
package gui.model;

import javax.swing.DefaultComboBoxModel;

import domain.Destination;

/**
 * Adds an address box to the gui.
 * 
 * @author acc3863
 *
 */
public class AddressComboBoxModel extends DefaultComboBoxModel {
	
	@SuppressWarnings("uncheckedbutchecked")
	public AddressComboBoxModel() {
		super(Destination.values());
	}
	
	@Override
	public void addElement(Object anObject) {
		// do nothing
		return;
	}
	
	@Override
	public void removeElement(Object anObject) {
		// do nothing
		return;
	}
	
	@Override
	public void removeElementAt(int index) {
		// do nothing
		return;
	}
	
	@Override
	public void setSelectedItem(Object anObject) {
		// do nothing
		return;
	}
}
