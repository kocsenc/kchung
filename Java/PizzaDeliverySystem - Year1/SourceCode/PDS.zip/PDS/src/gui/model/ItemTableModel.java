/**
 * 
 */
package gui.model;

import javax.swing.table.AbstractTableModel;

import data.ItemTracker;
import domain.Item;

/**
 * ItemTableModel implements a TableModel for Items.
 * 
 * @author acc3863
 * 
 */
public class ItemTableModel extends AbstractTableModel {

	private static Class<?>[] columnClasses = new Class<?>[] { String.class,
			String.class };
	private static String[] columnNames = new String[] { "Name", "Price" };

	@Override
	public int getColumnCount() {
		return columnNames.length;
	}

	@Override
	public String getColumnName(int columnIndex) {
		return columnNames[columnIndex];
	}

	@Override
	public Class<?> getColumnClass(int columnIndex) {
		return columnClasses[columnIndex];
	}

	@Override
	public int getRowCount() {
		return ItemTracker.getInstance().getData().size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Item i = ItemTracker.getInstance().getData().get(rowIndex);
		if (columnIndex == 0) {
			return i.getName();
		} else if (columnIndex == 1) {
			return i.getPriceString();
		} else {
			throw new RuntimeException("Invalid column index in itemtable");
		}
	}

}
