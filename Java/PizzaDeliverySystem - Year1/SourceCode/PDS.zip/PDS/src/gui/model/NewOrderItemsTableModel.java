package gui.model;

import gui.CreateOrderDialog;

import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.table.AbstractTableModel;

import domain.Item;

public class NewOrderItemsTableModel extends AbstractTableModel {

	List<Item> displayItems;

	public NewOrderItemsTableModel(List<Item> orderItems) {
		this.displayItems = orderItems;
	}

	@Override
	public String getColumnName(int col) {
		if (col == 0) {
			return "Item Name";
		} else if (col == 1) {
			return "Price";
		} else {
			return "Is Ready?";
		}
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 3;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return displayItems.size();
	}

	@Override
	public Object getValueAt(int row, int col) {
		if (col == 0) {
			return displayItems.get(row).getName();
		} else if (col == 1) {
			return displayItems.get(row).getPriceString();
		} else {
			if (displayItems.get(row).isPrepared()) {
				// display is prepared
				return "Yes";
			} else {
				return "No";
			}
		}

	}

}
