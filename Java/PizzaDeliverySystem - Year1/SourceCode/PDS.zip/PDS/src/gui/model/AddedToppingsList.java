package gui.model;

import java.util.List;

import javax.swing.AbstractListModel;

/**
 * AddedToppingsList generates a list for addedToppings on an
 * ordered pizza.
 * @author acc3863
 *
 */
public class AddedToppingsList extends AbstractListModel {

	List<Tuple<String, domain.Item.TSide>> addedToppings;

	public AddedToppingsList(List<Tuple<String, domain.Item.TSide>> arg1) {
		this.addedToppings = arg1;
	}
	/**
	 * getter for toString method for toppings.
	 */
	@Override
	public Object getElementAt(int i) {
		return addedToppings.get(i).first.toString() + " on " + addedToppings.get(i).second.toString();
		
	}
	/**
	 * getter for number of added toppings.
	 */
	@Override
	public int getSize() {
		return addedToppings.size();
	}
	/**
	 * remove topping from list at index position.
	 * @param index
	 */
	public void remove(int index) {
		this.remove(index);
	}
}
