package gui.model;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.AbstractAction;
import javax.swing.AbstractCellEditor;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;

/**
 * Adds JButtons to one column of a JTable along with an action to perform when
 * said button is pressed.
 * 
 * @author acc3863
 * 
 */
public class JButtonColumn extends AbstractCellEditor implements
		TableCellRenderer, TableCellEditor, ActionListener, MouseListener {

	private JTable targetTable;
	private Action action;
	private int mnemonicKey;
	private Border defaultBorder;
	private Border focusBorder;
	private JButton renderButton;
	private JButton editButton;
	private Object editorValue;
	private boolean isButtonColumnEditor;

	public JButtonColumn(JTable targetTable, Action action, int column) {
		this.targetTable = targetTable;
		this.action = action;
		this.renderButton = new JButton();
		this.editButton = new JButton();
		this.editButton.setFocusPainted(false);
		this.editButton.addActionListener(this);
		this.defaultBorder = editButton.getBorder();
		setFocusBorder(new LineBorder(java.awt.Color.BLUE));
		TableColumnModel columnModel = targetTable.getColumnModel();
		columnModel.getColumn(column).setCellRenderer(this);
		columnModel.getColumn(column).setCellEditor(this);
		this.targetTable.addMouseListener(this);

	}

	/**
	 * Gets the border of the button when focused.
	 * 
	 * @return the border
	 */
	public Border getFocusBorder() {
		return focusBorder;
	}

	/**
	 * Sets the border of the button when focused.
	 * 
	 * @param focusBorder
	 *            - the focused border.
	 */
	public void setFocusBorder(Border focusBorder) {
		this.focusBorder = focusBorder;
		editButton.setBorder(focusBorder);
	}

	/**
	 * Gets the mnemonic key code for the button.
	 * 
	 * @return the mnemonic key code.
	 */
	public int getMnemonicKey() {
		return mnemonicKey;
	}

	/**
	 * Sets the mnemonic key code for the button.
	 * 
	 * @param mnemonicKey
	 *            - the mnemonic key code.
	 */
	public void setMnemonicKey(int mnemonicKey) {
		this.mnemonicKey = mnemonicKey;
		this.renderButton.setMnemonic(mnemonicKey);
		this.editButton.setMnemonic(mnemonicKey);
	}

	@Override
	public Object getCellEditorValue() {
		return this.editorValue;
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	/**
	 * If we are the editor, enable actions.
	 */
	@Override
	public void mousePressed(MouseEvent arg0) {
		if (this.targetTable.isEditing()
				&& this.targetTable.getCellEditor() == this) {
			this.isButtonColumnEditor = true;
		}
	}

	/**
	 * If table is being edited and mouse is released, stop editing.
	 */
	@Override
	public void mouseReleased(MouseEvent arg0) {
		if (this.isButtonColumnEditor && this.targetTable.isEditing()) {
			this.targetTable.getCellEditor().stopCellEditing();
		}
		this.isButtonColumnEditor = false;
	}

	/**
	 * When button is pressed, fire our action.
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		int rowSelection = targetTable.convertRowIndexToModel(targetTable
				.getEditingRow());
		fireEditingStopped();
		ActionEvent aEvent = new ActionEvent(targetTable,
				ActionEvent.ACTION_PERFORMED, "" + rowSelection);
		this.action.actionPerformed(aEvent);
	}

	/**
	 * Set button based on parameters.
	 */
	@Override
	public Component getTableCellEditorComponent(JTable table, Object value,
			boolean isSelected, int row, int column) {
		if (value == null) {
			this.editButton.setText("");
			this.editButton.setIcon(null);
		} else if (value instanceof Icon) {
			this.editButton.setText("");
			this.editButton.setIcon((Icon) value);
		} else {
			this.editButton.setText(value.toString());
			this.editButton.setIcon(null);
		}

		this.editorValue = value;
		return this.editButton;
	}

	/**
	 * Set button based on parameters.
	 */
	@Override
	public Component getTableCellRendererComponent(JTable table, Object value,
			boolean isSelected, boolean hasFocus, int row, int column) {
		if (isSelected) {
			this.renderButton.setForeground(table.getSelectionForeground());
			this.renderButton.setBackground(table.getSelectionBackground());
		} else {
			this.renderButton.setForeground(table.getForeground());
			this.renderButton.setBackground(javax.swing.UIManager
					.getColor("Button.background"));
		}

		if (hasFocus) {
			this.renderButton.setBorder(focusBorder);
		} else {
			this.renderButton.setBorder(defaultBorder);
		}

		if (value == null) {
			this.renderButton.setText("");
			this.renderButton.setIcon(null);
		} else if (value instanceof Icon) {
			this.renderButton.setText("");
			this.renderButton.setIcon((Icon) value);
		} else {
			this.renderButton.setText(value.toString());
			this.renderButton.setIcon(null);
		}

		return this.renderButton;
	}

	
	// ========= TEST MAIN ===========
    public static void main(String[] args ) throws Throwable {
    	JFrame j = new JFrame("Test");
    	data.ItemTracker.getInstance().loadFromFile();
    	ImageIcon ii = new ImageIcon(JButtonColumn.class.getResource("/Icons/onebit_33.png"));
    	Object[][] rd = new Object[][]{
    			new Object[]{"1", "11", ii},
    			new Object[]{"2", "22", ii},
    			new Object[]{"3", "33", ii},
    			new Object[]{"4", "44", ii}
    	};
    	Object[] cn = new String[]{"One","Two","Delete"};
    	final JTable table = new JTable();
    	DefaultTableModel dtm = new DefaultTableModel(rd,cn);
    	table.setRowHeight(ii.getIconHeight());
    	table.setModel(dtm);
    	JButtonColumn bc = new JButtonColumn(table, new AbstractAction() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int modelRow = Integer.valueOf(e.getActionCommand());
				((DefaultTableModel)table.getModel()).removeRow(modelRow);
				table.revalidate();
			}}, 2);
    	j.setContentPane(table);
    	j.pack();
    	j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	j.setVisible(true);
    }
}
