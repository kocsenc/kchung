/*
 * newOrderDialog.java
 *
 * Created on __DATE__, __TIME__
 */

package gui;

import gui.model.ItemTableModel;
import gui.model.JButtonColumn;
import gui.model.NewOrderItemsTableModel;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;
import java.text.DecimalFormat;
import java.util.List;
import java.util.NoSuchElementException;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import data.CustomerTracker;
import data.ItemTracker;
import data.OrderTracker;
import domain.Customer;
import domain.Destination;
import domain.Item;
import domain.OrderStatus;
import domain.Item.Topping;
import domain.Order;

/**
 * Generates a pop-up window for creating orders.
 * 
 * @author kxc4519
 */
public class CreateOrderDialog extends javax.swing.JDialog {

	// Instantiating Local variables
	private List<Item> orderItems;
	private Customer theCustomer = null;
	private Destination theDestination;
	private boolean isEditing;
	private Order originalEditedOrder;

	/** Creates new form newOrderDialog */
	public CreateOrderDialog(java.awt.Frame parent, boolean modal) {
		super(parent, modal);
		initComponents();
		initItemTable();
		addressDropDown.setSelectedIndex(0);
		orderItems = new java.util.ArrayList<Item>();
		addressDropDown.setModel(new DefaultComboBoxModel(domain.Destination
				.values())); // See: domain.Destination for additional details
								// on model
		updateOrderTotalsList();
		this.setLocationRelativeTo(null);
		confirmOrderDialog.setLocationRelativeTo(null);
		isEditing = false;
	}

	/**
	 * Creates new CreateOrderDialog used to edit an order.
	 * 
	 * @param parent
	 *            - Parent frame
	 * @param modal
	 *            - True if modal
	 * @param o
	 *            - The order to edit
	 */
	public CreateOrderDialog(java.awt.Frame parent, boolean modal, final Order o) {
		this(parent, modal);
		// customer stuff
		theCustomer = o.getCustomer();
		nameField.setText(theCustomer.getName());
		phoneField.setText(theCustomer.getPhone());
		// order stuff
		orderItems = o.getItems();
		updateTotalPrice();
		updateOrderTotalsList();
		// destination stuff
		theDestination = o.getDestination();
		addressDropDown.setSelectedItem(theDestination);

		isEditing = true;
		originalEditedOrder = o;
	}

	/**
	 * This method is called to initialize the quantity of Items to display in
	 * the menu. Depending on the amount of items, the Table will display all of
	 * the items available in a list. Each item row will have a button to either
	 * add to the order or delete from the order. Order is not finalized when
	 * those buttons are clicked.
	 */
	private void initItemTable() {
		final List<Item> itracki = ItemTracker.getInstance().getData();
		ImageIcon addIcon = new ImageIcon(
				CreateOrderDialog.class.getResource("/Icons/Add.png"));
		Object[][] rowData = new Object[itracki.size()][];
		Object[] cNames = new Object[] { "Item", "Price", "Add" };
		for (int i = 0; i < itracki.size(); i++) {

			rowData[i] = new Object[] { itracki.get(i).getName(),
					itracki.get(i).getPriceString(), addIcon };
		}
		itemTable.setModel(new DefaultTableModel(rowData, cNames));
		itemTable.setRowHeight(addIcon.getIconHeight());
		JButtonColumn addCol = new JButtonColumn(itemTable,
				new AbstractAction() {

					@Override
					public void actionPerformed(ActionEvent e) {
						int mrow = Integer.valueOf(e.getActionCommand());
						// System.out.println(itracki.get(mrow).getName()
						// .contains("Pizza"));
						if (itracki.get(mrow).hasToppings()) {
							JDialog newPizzaDialog = new NewPizzaDialog(
									CreateOrderDialog.this, true,
									itracki.get(mrow));
							newPizzaDialog.setVisible(true);
						} else {
							addItemToOrder(itracki.get(mrow));
						}

					}

				}, 2);

	}

	/**
	 * Adds an item clone to the order items list, which will eventually be the
	 * items within the created order.
	 * 
	 * @param i
	 *            - The item to add to the Order's item list.
	 */
	public void addItemToOrder(Item i) {
		// System.out.println(i.getPrice());
		orderItems.add(i.clone());
		updateOrderTotalsList();
		// orderItemList.revalidate();
		updateTotalPrice();
	}

	/**
	 * Method that removes the item from the order items list. This means that
	 * when the "create order" button is pressed, this item i will not be in the
	 * order.
	 * 
	 * @param i
	 *            - The item to be removed to the Order's item list.
	 */
	private void removeItemFromOrder(Item i) {
		orderItems.remove(i);
		updateOrderTotalsList();
		updateTotalPrice();
	}

	/**
	 * Method that removes the item from the order items list. This means that
	 * when the "create order" button is pressed, this item i will not be in the
	 * order.
	 * 
	 * @param i
	 *            - The index of the item item to be removed to the Order's item
	 *            list.
	 */
	private void removeItemFromOrder(int i) {
		orderItems.remove(i);
		updateOrderTotalsList();
		updateTotalPrice();
	}

	/**
	 * Inner method that serves to update the List of all the added items. The
	 * way this is done is by resetting the model of the Table to the back-end
	 * model that it has been tracing.
	 */
	private void updateOrderTotalsList() {
		Object[][] tdata = new Object[orderItems.size()][];
		Object[] cnames = new Object[] { "Name", "Price", "Remove" };
		ImageIcon remIcon = new ImageIcon(
				CreateOrderDialog.class.getResource("/Icons/onebit_32.png"));
		for (int i = 0; i < orderItems.size(); i++) {
			Item ii = orderItems.get(i);
			tdata[i] = new Object[] { ii.getName(), ii.getPriceString(),
					remIcon };
		}
		orderTotalTable.setModel(new DefaultTableModel(tdata, cnames));
		orderTotalTable.setRowHeight(remIcon.getIconHeight());
		JButtonColumn remCol = new JButtonColumn(orderTotalTable,
				new AbstractAction() {

					@Override
					public void actionPerformed(ActionEvent e) {
						int mrow = Integer.valueOf(e.getActionCommand());
						removeItemFromOrder(mrow);
					}

				}, 2);
		updateTotalPrice();

	}

	/**
	 * Inner method that serves to update the big display that shows the total
	 * of the order. We make sure to format the float to appear as a currency
	 * number.
	 */
	private void updateTotalPrice() {

		float total = 0;
		for (Item i : orderItems) {
			total += i.getPrice();
		}
		totalDueField
				.setText(DecimalFormat.getCurrencyInstance().format(total));
		confirmationTotalField.setText(DecimalFormat.getCurrencyInstance()
				.format(total));

	}

	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always
	 * regenerated by the Form Editor.
	 */
	// GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		confirmOrderDialog = new javax.swing.JDialog();
		jPanel1 = new javax.swing.JPanel();
		confirmBackButton = new javax.swing.JButton();
		confirmConfirmButton = new javax.swing.JButton();
		jScrollPane2 = new javax.swing.JScrollPane();
		confirmOrderDialogItemsTable = new javax.swing.JTable();
		jPanel2 = new javax.swing.JPanel();
		customerNameConfirmationField = new javax.swing.JTextField();
		customerPhoneConfirmationField = new javax.swing.JTextField();
		customerDestinationConfirmationField = new javax.swing.JTextField();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		dialogEstimatedTimeField = new javax.swing.JTextField();
		jLabel2 = new javax.swing.JLabel();
		jLabel1 = new javax.swing.JLabel();
		confirmationTotalField = new javax.swing.JTextField();
		backButton = new javax.swing.JButton();
		placeOrder = new javax.swing.JButton();
		customerPanel = new javax.swing.JPanel();
		nameField = new javax.swing.JTextField();
		phoneField = new javax.swing.JTextField();
		addressDropDown = new javax.swing.JComboBox();
		name = new javax.swing.JLabel();
		address = new javax.swing.JLabel();
		telephone = new javax.swing.JLabel();
		customerLookupButton = new javax.swing.JButton();
		menuPanel = new javax.swing.JPanel();
		itemScrollPane = new javax.swing.JScrollPane();
		itemTable = new javax.swing.JTable();
		totalPanel = new javax.swing.JPanel();
		jScrollPane1 = new javax.swing.JScrollPane();
		orderTotalTable = new javax.swing.JTable();
		jLabel8 = new javax.swing.JLabel();
		jLabel7 = new javax.swing.JLabel();
		totalDueField = new javax.swing.JLabel();

		confirmOrderDialog
				.setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
		confirmOrderDialog.setTitle("Order Confirmation");
		confirmOrderDialog.setMinimumSize(new java.awt.Dimension(650, 500));
		confirmOrderDialog.setModal(true);
		confirmOrderDialog.setResizable(false);

		confirmBackButton.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/onebit_29.png"))); // NOI18N
		confirmBackButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						confirmBackButtonActionPerformed(evt);
					}
				});

		confirmConfirmButton.setFont(new java.awt.Font("Segoe UI", 0, 36));
		confirmConfirmButton.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/Check.png"))); // NOI18N
		confirmConfirmButton.setText("Confirm Order");
		confirmConfirmButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						confirmConfirmButtonActionPerformed(evt);
					}
				});

		confirmOrderDialogItemsTable
				.setModel(new javax.swing.table.DefaultTableModel(
						new Object[][] { { null, null }, { null, null } },
						new String[] { "Title 1", "Title 2" }));
		jScrollPane2.setViewportView(confirmOrderDialogItemsTable);

		customerNameConfirmationField.setEditable(false);
		customerNameConfirmationField.setFont(new java.awt.Font("Segoe UI", 0,
				14));

		customerPhoneConfirmationField.setEditable(false);
		customerPhoneConfirmationField.setFont(new java.awt.Font("Segoe UI", 0,
				14));

		customerDestinationConfirmationField.setEditable(false);
		customerDestinationConfirmationField.setFont(new java.awt.Font(
				"Segoe UI", 0, 14));

		jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18));
		jLabel3.setText("Order for:");

		jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18));
		jLabel4.setText("with phone #:");

		jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18));
		jLabel5.setText("and Bound to:");

		jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18));
		jLabel6.setText("Estmt Deliver Time:");

		dialogEstimatedTimeField.setEditable(false);

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel2Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																dialogEstimatedTimeField,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																189,
																Short.MAX_VALUE)
														.addComponent(
																jLabel6,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																189,
																Short.MAX_VALUE)
														.addComponent(
																jLabel5,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																189,
																Short.MAX_VALUE)
														.addComponent(
																jLabel4,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																189,
																Short.MAX_VALUE)
														.addComponent(
																jLabel3,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																189,
																Short.MAX_VALUE)
														.addComponent(
																customerNameConfirmationField,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																189,
																Short.MAX_VALUE)
														.addComponent(
																customerPhoneConfirmationField,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																189,
																Short.MAX_VALUE)
														.addComponent(
																customerDestinationConfirmationField,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																189,
																Short.MAX_VALUE))
										.addContainerGap()));
		jPanel2Layout
				.setVerticalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												jLabel3,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												34,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												customerNameConfirmationField,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												28,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jLabel4)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												customerPhoneConfirmationField,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												27,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(jLabel5)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												customerDestinationConfirmationField,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												31,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jLabel6,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												35,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												dialogEstimatedTimeField,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												36, Short.MAX_VALUE)));

		jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 24));
		jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel2.setText("Confirm Items and Customer Information");

		jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24));
		jLabel1.setText("TOTAL");

		confirmationTotalField.setEditable(false);
		confirmationTotalField.setFont(new java.awt.Font("Segoe UI", 0, 24));
		confirmationTotalField.setText("$");
		confirmationTotalField.setToolTipText("This is the Total");

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(12,
																				12,
																				12)
																		.addComponent(
																				confirmBackButton,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				160,
																				Short.MAX_VALUE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				confirmConfirmButton,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				369,
																				Short.MAX_VALUE))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jScrollPane2,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								316,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jLabel1,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												158,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												confirmationTotalField,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												153,
																												javax.swing.GroupLayout.PREFERRED_SIZE)))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jPanel2,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jLabel2,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				536,
																				Short.MAX_VALUE)))
										.addContainerGap()));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												jLabel2,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												24,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																jPanel2,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addComponent(
																				jScrollPane2,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				243,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING,
																								false)
																						.addComponent(
																								confirmationTotalField)
																						.addComponent(
																								jLabel1,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								45,
																								Short.MAX_VALUE))))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																confirmConfirmButton,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																100,
																Short.MAX_VALUE)
														.addComponent(
																confirmBackButton,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																100,
																Short.MAX_VALUE))
										.addContainerGap()));

		javax.swing.GroupLayout confirmOrderDialogLayout = new javax.swing.GroupLayout(
				confirmOrderDialog.getContentPane());
		confirmOrderDialog.getContentPane().setLayout(confirmOrderDialogLayout);
		confirmOrderDialogLayout.setHorizontalGroup(confirmOrderDialogLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.PREFERRED_SIZE));
		confirmOrderDialogLayout.setVerticalGroup(confirmOrderDialogLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(jPanel1,
						javax.swing.GroupLayout.Alignment.TRAILING,
						javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
		setTitle("Create a New Order");
		setModal(true);

		backButton.setFont(new java.awt.Font("Tahoma", 0, 24));
		backButton.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/Icons/onebit_33.png"))); // NOI18N
		backButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				backButtonActionPerformed(evt);
			}
		});

		placeOrder.setFont(new java.awt.Font("Tahoma", 0, 24));
		placeOrder.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/Icons/Check.png"))); // NOI18N
		placeOrder.setText("Place\nOrder");
		placeOrder.setBorder(null);
		placeOrder.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				placeOrderActionPerformed(evt);
			}
		});

		customerPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(
				new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0),
						2, true), "1. Fill In Customer Info",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Segoe UI Semibold", 0, 18)));

		nameField.setFont(new java.awt.Font("Segoe UI", 0, 18));

		phoneField.setFont(new java.awt.Font("Segoe UI", 0, 18));

		addressDropDown.setFont(new java.awt.Font("Segoe UI", 0, 14));
		addressDropDown.setModel(new javax.swing.DefaultComboBoxModel(
				new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
		addressDropDown.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				addressDropDownActionPerformed(evt);
			}
		});

		name.setText("Name");

		address.setText("Address");

		telephone.setText("Telephone");

		customerLookupButton.setText("Look Up Customer");
		customerLookupButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						customerLookupButtonActionPerformed(evt);
					}
				});

		javax.swing.GroupLayout customerPanelLayout = new javax.swing.GroupLayout(
				customerPanel);
		customerPanel.setLayout(customerPanelLayout);
		customerPanelLayout
				.setHorizontalGroup(customerPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								customerPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												customerPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																customerPanelLayout
																		.createSequentialGroup()
																		.addComponent(
																				telephone)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				81,
																				Short.MAX_VALUE)
																		.addComponent(
																				phoneField,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				278,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																customerPanelLayout
																		.createSequentialGroup()
																		.addGroup(
																				customerPanelLayout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								customerPanelLayout
																										.createSequentialGroup()
																										.addComponent(
																												name)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																												105,
																												Short.MAX_VALUE))
																						.addGroup(
																								customerPanelLayout
																										.createSequentialGroup()
																										.addComponent(
																												address,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												121,
																												Short.MAX_VALUE)
																										.addGap(16,
																												16,
																												16)))
																		.addGroup(
																				customerPanelLayout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING,
																								false)
																						.addComponent(
																								addressDropDown,
																								javax.swing.GroupLayout.Alignment.TRAILING,
																								0,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE)
																						.addComponent(
																								nameField,
																								javax.swing.GroupLayout.Alignment.TRAILING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								278,
																								Short.MAX_VALUE)
																						.addComponent(
																								customerLookupButton,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								Short.MAX_VALUE))))
										.addContainerGap()));
		customerPanelLayout
				.setVerticalGroup(customerPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								customerPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												customerPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																telephone,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																35,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																phoneField,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																33,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												customerPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(name)
														.addComponent(
																nameField,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																33,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												customerPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																address,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																27,
																Short.MAX_VALUE)
														.addComponent(
																addressDropDown,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																33,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												customerLookupButton,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												33,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(48, 48, 48)));

		menuPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(
				new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0),
						2, true), "2. Select Menu Items",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Segoe UI Semibold", 1, 18)));

		itemTable.setModel(new javax.swing.table.DefaultTableModel(
				new Object[][] { { null, null, null, null },
						{ null, null, null, null }, { null, null, null, null },
						{ null, null, null, null } }, new String[] { "Title 1",
						"Title 2", "Title 3", "Title 4" }));
		itemScrollPane.setViewportView(itemTable);

		javax.swing.GroupLayout menuPanelLayout = new javax.swing.GroupLayout(
				menuPanel);
		menuPanel.setLayout(menuPanelLayout);
		menuPanelLayout.setHorizontalGroup(menuPanelLayout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				menuPanelLayout
						.createSequentialGroup()
						.addContainerGap()
						.addComponent(itemScrollPane,
								javax.swing.GroupLayout.DEFAULT_SIZE, 444,
								Short.MAX_VALUE).addContainerGap()));
		menuPanelLayout.setVerticalGroup(menuPanelLayout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				javax.swing.GroupLayout.Alignment.TRAILING,
				menuPanelLayout
						.createSequentialGroup()
						.addContainerGap()
						.addComponent(itemScrollPane,
								javax.swing.GroupLayout.DEFAULT_SIZE, 730,
								Short.MAX_VALUE).addContainerGap()));

		totalPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(
				new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0),
						1, true), "Order Totals - Shopping Cart",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Segoe UI", 0, 18)));

		orderTotalTable.setModel(new javax.swing.table.DefaultTableModel(
				new Object[][] { { null, null } }, new String[] { "Title 1",
						"Title 2" }));
		jScrollPane1.setViewportView(orderTotalTable);

		jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 36));
		jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel8.setText("TOTAL");

		jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 36));
		jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel7.setText("Total");

		totalDueField.setFont(new java.awt.Font("Segoe UI", 0, 36));
		totalDueField.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

		javax.swing.GroupLayout totalPanelLayout = new javax.swing.GroupLayout(
				totalPanel);
		totalPanel.setLayout(totalPanelLayout);
		totalPanelLayout
				.setHorizontalGroup(totalPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								totalPanelLayout
										.createSequentialGroup()
										.addGroup(
												totalPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																jLabel8,
																javax.swing.GroupLayout.Alignment.TRAILING,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																144,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addGroup(
																totalPanelLayout
																		.createSequentialGroup()
																		.addGap(12,
																				12,
																				12)
																		.addComponent(
																				jScrollPane1,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				417,
																				Short.MAX_VALUE))
														.addGroup(
																totalPanelLayout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jLabel7,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				193,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				totalDueField,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				217,
																				Short.MAX_VALUE)))
										.addContainerGap()));
		totalPanelLayout
				.setVerticalGroup(totalPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								totalPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												jScrollPane1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												247,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												totalPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																totalPanelLayout
																		.createSequentialGroup()
																		.addComponent(
																				totalDueField,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				47,
																				Short.MAX_VALUE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabel8,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				0,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addComponent(
																jLabel7,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																54,
																Short.MAX_VALUE))
										.addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						layout.createSequentialGroup()
								.addContainerGap()
								.addComponent(menuPanel,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.TRAILING)
												.addComponent(
														totalPanel,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														Short.MAX_VALUE)
												.addComponent(
														customerPanel,
														javax.swing.GroupLayout.Alignment.LEADING,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														Short.MAX_VALUE)
												.addGroup(
														javax.swing.GroupLayout.Alignment.LEADING,
														layout.createSequentialGroup()
																.addComponent(
																		backButton,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		116,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addGap(12, 12,
																		12)
																.addComponent(
																		placeOrder,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		323,
																		Short.MAX_VALUE)))
								.addContainerGap()));
		layout.setVerticalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						javax.swing.GroupLayout.Alignment.TRAILING,
						layout.createSequentialGroup()
								.addContainerGap()
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.TRAILING)
												.addComponent(
														menuPanel,
														javax.swing.GroupLayout.Alignment.LEADING,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														Short.MAX_VALUE)
												.addGroup(
														layout.createSequentialGroup()
																.addComponent(
																		customerPanel,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		Short.MAX_VALUE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(
																		totalPanel,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addGroup(
																		layout.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																				.addComponent(
																						backButton,
																						javax.swing.GroupLayout.DEFAULT_SIZE,
																						158,
																						Short.MAX_VALUE)
																				.addComponent(
																						placeOrder,
																						javax.swing.GroupLayout.DEFAULT_SIZE,
																						158,
																						Short.MAX_VALUE))))
								.addContainerGap()));

		pack();
	}// </editor-fold>
		// GEN-END:initComponents

	/**
	 * Watches for customer look-ups via phone or name.
	 */
	private void customerLookupButtonActionPerformed(
			java.awt.event.ActionEvent evt) {
		String phone;
		try {
			phone = Customer.parsePhone(phoneField.getText());
		} catch (NoSuchElementException e) {
			phone = phoneField.getText();
		}
		String name = nameField.getText();
		if (CustomerTracker.getInstance().getCustomer(phone) != null) {
			// if exists, then fill out information
			nameField.setText(CustomerTracker.getInstance().getCustomer(phone)
					.getName());
			phoneField.setText(CustomerTracker.getInstance().getCustomer(phone)
					.getPhone());
			theCustomer = CustomerTracker.getInstance().getCustomer(phone);

		} else if (CustomerTracker.getInstance().getCustomer(name) != null) {
			phoneField.setText(CustomerTracker.getInstance().getCustomer(name)
					.getPhone());
			nameField.setText(CustomerTracker.getInstance().getCustomer(name)
					.getName());
			theCustomer = CustomerTracker.getInstance().getCustomer(name);
		} else {
			JOptionPane
					.showMessageDialog(
							this,
							"Customer not found. Complete the customer information and then \nPlace Order to proceed the order with the new customer.");
		}

	}

	/**
	 * TELEPHONE FIELD ACTION
	 * 
	 * @param evt
	 */
	private void phoneFieldActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	/**
	 * This is the Drop Down to pick the address of where this order is going.
	 * There are only a few locations, and the model for the drop down box are
	 * set above.
	 * 
	 * @param evt
	 */
	private void addressDropDownActionPerformed(java.awt.event.ActionEvent evt) {
		theDestination = Destination.values()[addressDropDown
				.getSelectedIndex()];
	}

	/**
	 * This is a bonus functionality to satisfy the user. This method consists
	 * of updating the Total Due Field next to the word TOTAL when it is clicked
	 * by the user.
	 * 
	 * @param evt
	 */
	private void totalDueFieldActionPerformed(java.awt.event.ActionEvent evt) {
		totalDueField.revalidate();
	}

	/**
	 * This method is the code triggered when clicking on the Add pizza button.
	 * It will make sure that the items offered by the store even contain a
	 * small, medium and large pizza. IF they dont, then a warning will show the
	 * user that they cannot add a pizza to the order since the store does not
	 * sell them. Furthermore, if all the pizzas are offered by the store, the
	 * new pizza dialog is launched to add a personalized pizza to the order.
	 * 
	 * @param evt
	 */
	private void pizzaAddButtonActionPerformed(java.awt.event.ActionEvent evt) {
		System.out.println("DISABLED OPTION");
		return;
	}

	// ***********************New Order BEGIN **************//

	/**
	 * BACK BUTTON This closes this frame.
	 * 
	 * @param evt
	 */
	protected void backButtonActionPerformed(ActionEvent evt) {
		this.dispose();

	}

	private void makeCustomer() {

		if (!nameField.getText().isEmpty() && !phoneField.getText().isEmpty()) {

			theCustomer = new Customer(nameField.getText(),
					phoneField.getText());
			CustomerTracker.getInstance().addData(theCustomer);
			// return true;
		} else {

			JOptionPane.showMessageDialog(this,
					"Make sure to have Contact Info filled out");
			// return false;

		}
	}

	/**
	 * PLACE ORDER BUTTON (PRIOR TO CONFIRMATION)
	 * 
	 * This button does not actually instantiate the order. Rather, it launches
	 * up a confirmation window that is meant do make sure of the placement of
	 * this new order.
	 * 
	 * @param evt
	 */
	private void placeOrderActionPerformed(java.awt.event.ActionEvent evt) {
		boolean cust = false;
		String phone;

		try {
			if (theCustomer == null) {// have to make new customer
				makeCustomer();

			} else { // if theCustomer != null; if previously found or found and
						// then changed.
				try {
					phone = Customer.parsePhone(phoneField.getText());
				} catch (NoSuchElementException e) {
					phone = phoneField.getText();
				}
				if (CustomerTracker.getInstance().getCustomer(phone) == null) {
					makeCustomer();

				} else if (CustomerTracker.getInstance().getCustomer(phone) != null) {
					theCustomer = CustomerTracker.getInstance().getCustomer(
							phone);
				}

			}
		} catch (IllegalArgumentException e) {
			JOptionPane
					.showMessageDialog(this,
							"Check for valid 10 or 7 digit phone number, name and destination please");
			cust = true;

		}

		if (theCustomer != null && !orderItems.isEmpty()
				&& theDestination != null) {

			// System.out.println("OK to make order");
			// System.out.println("Customer: " + theCustomer.getName()
			// + " with customer info: " + theCustomer.getPhone());
			// System.out.println("Items are not empty");
			// System.out.println("The Destination is: "
			// + theDestination.toString());

			confirmOrderDialogItemsTable.setModel(new NewOrderItemsTableModel(
					orderItems));
			updateTotalPrice();
			customerNameConfirmationField.setText(theCustomer.getName());
			customerPhoneConfirmationField.setText(theCustomer.getPhone());
			customerDestinationConfirmationField.setText(theDestination
					.toString());
			int maxTimeItem = 0;
			for (int i = 0; i < orderItems.size(); i++) {
				maxTimeItem = Math.max(maxTimeItem, orderItems.get(i)
						.getCookTime() + orderItems.get(i).getPrepTime());
			}
			dialogEstimatedTimeField.setText(OrderTracker.formatTime(theDestination
					.getTimeTo()
					+ theDestination.getCollectionTime()
					+ maxTimeItem
					+ OrderTracker.getInstance().getTotalTime()));
			confirmOrderDialog.setVisible(true);

		} else {
			if (cust == false) {
				JOptionPane
						.showMessageDialog(this,
								"Remember to have Customer info, items in the cart and a destination selected!");
				cust = false;
			}
			cust = false;
		}

	}

	// ***********************New Order END***************//

	// *********************** Confirm new order dialog BEGIN ******//
	/**
	 * Dialog - CONFIRM ORDER BUTTON This button actually triggers the
	 * instantiation of the Order with all the items.
	 * 
	 * @param evt
	 */
	private void confirmConfirmButtonActionPerformed(
			java.awt.event.ActionEvent evt) {

		Order theOrder = new Order(orderItems, theCustomer, theDestination);
		if (isEditing) {
			// System.out.println("Canceling original order: " +
			// originalEditedOrder.toString());
			if(originalEditedOrder.getStatus() != OrderStatus.IN_PREP) {
				// not in prep can't edit
				JOptionPane.showMessageDialog(this, "This order has already been delivered. Canceling Edit.");
				confirmOrderDialog.dispose();
				this.dispose();
				return;
			}
			OrderTracker.getInstance().cancelOrder(originalEditedOrder);
		}
		OrderTracker.getInstance().addData(theOrder);
		confirmOrderDialog.dispose();
		this.dispose();
	}

	/**
	 * Dialog - BACK BUTTON
	 * 
	 * @param evt
	 */
	private void confirmBackButtonActionPerformed(java.awt.event.ActionEvent evt) {
		confirmOrderDialog.setVisible(false);
		confirmOrderDialog.dispose();
	}

	// *********************** Confirm new order dialog END ******//

	// GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JLabel address;
	private javax.swing.JComboBox addressDropDown;
	private javax.swing.JButton backButton;
	private javax.swing.JButton confirmBackButton;
	private javax.swing.JButton confirmConfirmButton;
	private javax.swing.JDialog confirmOrderDialog;
	private javax.swing.JTable confirmOrderDialogItemsTable;
	private javax.swing.JTextField confirmationTotalField;
	private javax.swing.JTextField customerDestinationConfirmationField;
	private javax.swing.JButton customerLookupButton;
	private javax.swing.JTextField customerNameConfirmationField;
	private javax.swing.JPanel customerPanel;
	private javax.swing.JTextField customerPhoneConfirmationField;
	private javax.swing.JTextField dialogEstimatedTimeField;
	private javax.swing.JScrollPane itemScrollPane;
	private javax.swing.JTable itemTable;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JPanel menuPanel;
	private javax.swing.JLabel name;
	private javax.swing.JTextField nameField;
	private javax.swing.JTable orderTotalTable;
	private javax.swing.JTextField phoneField;
	private javax.swing.JButton placeOrder;
	private javax.swing.JLabel telephone;
	private javax.swing.JLabel totalDueField;
	private javax.swing.JPanel totalPanel;
	// End of variables declaration//GEN-END:variables

}