/*
 * NewPizzaDialog.java
 *
 * Created on __DATE__, __TIME__
 */

package gui;

import gui.model.AddedToppingsList;
import gui.model.Tuple;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

import data.ItemTracker;
import domain.Item;
import domain.Item.TSide;
import domain.Item.Topping;

/**
 * Generates a window for creating a new pizza when customer orders it.
 * 
 * @author _kxc4519
 */
public class NewPizzaDialog extends javax.swing.JDialog {

	// Setting Pizza Topping Variables
	private static String[] toppings = new String[] { "Pepperoni", "Sausage",
			"Onions", "Peppers", "Mushrooms" };
	private static float[] prices = new float[] { 1f, 1.5f, 2f };
	private static List<Tuple<String, TSide>> addedToppings;
	private domain.Item.TSide toppingSide;
	private domain.Item itemType;
	private int pizzaSize = 1; // 0=small; 1=med; 2=large

	/**
	 * Method below inits the GUI components for the new pizza dialog and sets
	 * preliminary selections.
	 */
	/** Creates new form NewPizzaDialog */
	public NewPizzaDialog(java.awt.Dialog parent, boolean modal, Item i) {
		super(parent, modal);
		initComponents();

		this.setLocationRelativeTo(null);

		// addedToppings is array list of tuples<name, side>
		addedToppings = new ArrayList<Tuple<String, TSide>>();

		updateToppingsList();

		// !!Change
		topping1ButtonGroup.setSelected(wholeRButton.getModel(), true); // Set
																		// WHOLE
																		// selected

		toppingsDropDown.setModel(new DefaultComboBoxModel(toppings)); // Set
																		// DefaultModel
																		// for
																		// drop
																		// down
		// !!Change - Setting default Whole, and 1 pepperonni topping.
		toppingSide = domain.Item.TSide.ALL; // set toppingSide to enum
												// WHOLE/ALL
		addedToppings.add(new Tuple<String, domain.Item.TSide>(toppings[0], // Adding
																			// pepperoni
																			// default
																			// pizza.
				domain.Item.TSide.ALL));
		updateToppingsList();

		itemType = i;
		pizzaSize = determineSize();
		addNewPizzaMenuTitleLabel.setText("New " + i.getName());
	}

	/**
	 * Method used to see what size of pizza is being ordered. This will be used
	 * to determine the topping prices.
	 * 
	 * @return int where 0 small and 2 is large. Else, 1 will be default for
	 *         toppings on any item.
	 */
	private int determineSize() {
		if (itemType.getName().contains("Small")) {
			return 0;
		} else if (itemType.getName().contains("Medium")) {
			return 1;
		} else if (itemType.getName().contains("Large")) {
			return 2;
		} else {
			return 1;
		}
	}

	/**
	 * Resets the model for the toppings list to make sure its populated
	 * correctly. it also disables the REMOVE button if there is no toppings
	 * added.
	 */
	private void updateToppingsList() {
		addedToppingsList.setModel(new AddedToppingsList(addedToppings));
		removeToppingButton.setEnabled(addedToppings.size() != 0);

	}

	// GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		topping1ButtonGroup = new javax.swing.ButtonGroup();
		jPanel1 = new javax.swing.JPanel();
		addPizzaButton = new javax.swing.JButton();
		addNewPizzaMenuTitleLabel = new javax.swing.JLabel();
		cancelNewPizzaButton = new javax.swing.JButton();
		selectToppingsPanel = new javax.swing.JPanel();
		leftRButton = new javax.swing.JRadioButton();
		wholeRButton = new javax.swing.JRadioButton();
		rightRButton = new javax.swing.JRadioButton();
		addToppingButton = new javax.swing.JButton();
		removeToppingButton = new javax.swing.JButton();
		jScrollPane1 = new javax.swing.JScrollPane();
		addedToppingsList = new javax.swing.JList();
		toppingsDropDown = new javax.swing.JComboBox();
		selectQuantityPanel = new javax.swing.JPanel();
		quantityPizzasSpinner = new javax.swing.JSpinner();
		jLabel2 = new javax.swing.JLabel();

		topping1ButtonGroup.add(leftRButton);
		topping1ButtonGroup.add(wholeRButton);
		topping1ButtonGroup.add(rightRButton);

		setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
		setTitle("Add a New Pizza");

		addPizzaButton.setFont(new java.awt.Font("Segoe UI", 0, 36));
		addPizzaButton.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/Add.png"))); // NOI18N
		addPizzaButton.setText("Add");
		addPizzaButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				addPizzaButtonActionPerformed(evt);
			}
		});

		addNewPizzaMenuTitleLabel.setFont(new java.awt.Font("Segoe UI", 0, 36));
		addNewPizzaMenuTitleLabel
				.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		addNewPizzaMenuTitleLabel.setText("Add New Pizza");

		cancelNewPizzaButton.setFont(new java.awt.Font("Segoe UI", 0, 36));
		cancelNewPizzaButton.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/onebit_33.png"))); // NOI18N
		cancelNewPizzaButton.setText("Cancel");
		cancelNewPizzaButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						cancelNewPizzaButtonActionPerformed(evt);
					}
				});

		selectToppingsPanel.setBorder(javax.swing.BorderFactory
				.createTitledBorder(new javax.swing.border.LineBorder(
						new java.awt.Color(0, 0, 0), 2, true), "1. Toppings"));

		leftRButton.setFont(new java.awt.Font("Segoe UI", 0, 14));
		leftRButton.setText("Left");
		leftRButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				leftRButtonActionPerformed(evt);
			}
		});

		wholeRButton.setFont(new java.awt.Font("Segoe UI", 0, 14));
		wholeRButton.setText("Whole");
		wholeRButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				wholeRButtonActionPerformed(evt);
			}
		});

		rightRButton.setFont(new java.awt.Font("Segoe UI", 0, 14));
		rightRButton.setText("Right");
		rightRButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				rightRButtonActionPerformed(evt);
			}
		});

		addToppingButton.setFont(new java.awt.Font("Segoe UI", 0, 24));
		addToppingButton.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/onebit_28.png"))); // NOI18N
		addToppingButton.setText("Add Topping");
		addToppingButton
				.setToolTipText("Click here to add the topping selected above to the pizza");
		addToppingButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				addToppingButtonActionPerformed(evt);
			}
		});

		removeToppingButton.setFont(new java.awt.Font("Segoe UI", 0, 18));
		removeToppingButton.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/onebit_30.png"))); // NOI18N
		removeToppingButton.setText("Remove Topping");
		removeToppingButton.setEnabled(false);
		removeToppingButton
				.addActionListener(new java.awt.event.ActionListener() {
					public void actionPerformed(java.awt.event.ActionEvent evt) {
						removeToppingButtonActionPerformed(evt);
					}
				});

		addedToppingsList
				.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		addedToppingsList.setToolTipText("");
		jScrollPane1.setViewportView(addedToppingsList);

		toppingsDropDown.setFont(new java.awt.Font("Segoe UI", 0, 14));
		toppingsDropDown.setModel(new javax.swing.DefaultComboBoxModel(
				new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

		javax.swing.GroupLayout selectToppingsPanelLayout = new javax.swing.GroupLayout(
				selectToppingsPanel);
		selectToppingsPanel.setLayout(selectToppingsPanelLayout);
		selectToppingsPanelLayout
				.setHorizontalGroup(selectToppingsPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								selectToppingsPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												selectToppingsPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																selectToppingsPanelLayout
																		.createSequentialGroup()
																		.addGroup(
																				selectToppingsPanelLayout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								selectToppingsPanelLayout
																										.createSequentialGroup()
																										.addComponent(
																												toppingsDropDown,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												162,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																												87,
																												Short.MAX_VALUE)
																										.addComponent(
																												leftRButton,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												86,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												wholeRButton,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												91,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												rightRButton)
																										.addGap(12,
																												12,
																												12))
																						.addGroup(
																								selectToppingsPanelLayout
																										.createSequentialGroup()
																										.addComponent(
																												removeToppingButton,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												495,
																												Short.MAX_VALUE)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
																		.addGap(12,
																				12,
																				12))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																selectToppingsPanelLayout
																		.createSequentialGroup()
																		.addGroup(
																				selectToppingsPanelLayout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								jScrollPane1,
																								javax.swing.GroupLayout.Alignment.LEADING,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								495,
																								Short.MAX_VALUE)
																						.addComponent(
																								addToppingButton,
																								javax.swing.GroupLayout.DEFAULT_SIZE,
																								495,
																								Short.MAX_VALUE))
																		.addContainerGap()))));
		selectToppingsPanelLayout
				.setVerticalGroup(selectToppingsPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								selectToppingsPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												selectToppingsPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																toppingsDropDown,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																41,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																wholeRButton)
														.addComponent(
																rightRButton)
														.addComponent(
																leftRButton))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												addToppingButton,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												67,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jScrollPane1,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												291, Short.MAX_VALUE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												removeToppingButton,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												67,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap()));

		selectQuantityPanel.setBorder(javax.swing.BorderFactory
				.createTitledBorder(new javax.swing.border.LineBorder(
						new java.awt.Color(0, 0, 0), 2, true), "2. How Many?"));

		quantityPizzasSpinner.setFont(new java.awt.Font("Tahoma", 0, 36));
		quantityPizzasSpinner.setModel(new javax.swing.SpinnerNumberModel(1, 1,
				9999, 1));

		jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18));
		jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
		jLabel2.setText("Quantity of Pizzas");

		javax.swing.GroupLayout selectQuantityPanelLayout = new javax.swing.GroupLayout(
				selectQuantityPanel);
		selectQuantityPanel.setLayout(selectQuantityPanelLayout);
		selectQuantityPanelLayout
				.setHorizontalGroup(selectQuantityPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								selectQuantityPanelLayout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												jLabel2,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												235,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												115, Short.MAX_VALUE)
										.addComponent(
												quantityPizzasSpinner,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												157,
												javax.swing.GroupLayout.PREFERRED_SIZE)));
		selectQuantityPanelLayout
				.setVerticalGroup(selectQuantityPanelLayout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								selectQuantityPanelLayout
										.createSequentialGroup()
										.addGroup(
												selectQuantityPanelLayout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																jLabel2,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																50,
																Short.MAX_VALUE)
														.addComponent(
																quantityPizzasSpinner,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addContainerGap(
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)));

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(addNewPizzaMenuTitleLabel,
								javax.swing.GroupLayout.DEFAULT_SIZE, 531,
								Short.MAX_VALUE)
						.addComponent(selectToppingsPanel,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addComponent(
												cancelNewPizzaButton,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												240,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												addPizzaButton,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												284, Short.MAX_VALUE))
						.addComponent(selectQuantityPanel,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addComponent(
												addNewPizzaMenuTitleLabel,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												53,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												selectToppingsPanel,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												selectQuantityPanel,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																cancelNewPizzaButton,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																86,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																addPizzaButton,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																86,
																Short.MAX_VALUE))
										.addContainerGap()));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup()
						.addContainerGap()
						.addComponent(jPanel1,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE).addContainerGap()));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				layout.createSequentialGroup()
						.addContainerGap()
						.addComponent(jPanel1,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE).addContainerGap()));

		pack();
	}// </editor-fold>
		// GEN-END:initComponents

	/**
	 * STEP 1 - Sets local variable pizzaSize = to a number depending on which
	 * one is pressed. These are sizes, where 0 = s; 1 = m; 2 = large.
	 * 
	 */
	// ********************** Step1 - Selecting Size BEGIN********************//

	/**
	 * ADD TOPPING BUTTON - This button actually adds the selected topping to
	 * the added toppings list. The added toppings list is the preliminary
	 * Editable list prior to concreting the pizza creation.
	 * 
	 * @param evt
	 */
	private void addToppingButtonActionPerformed(java.awt.event.ActionEvent evt) {
		String selection = (String) toppingsDropDown.getSelectedItem();

		if (selection != null) {
			addedToppings.add(new Tuple<String, domain.Item.TSide>(selection,
					toppingSide));
			updateToppingsList();
		}
	}

	/**
	 * REMOVE TOPPING BUTTON - This button actually removes the selected topping
	 * from the added toppings list. The added toppings list is the preliminary
	 * Editable list prior to concreting the pizza creation.
	 * 
	 * @param evt
	 */
	private void removeToppingButtonActionPerformed(
			java.awt.event.ActionEvent evt) {
		int indexToRemove = addedToppingsList.getSelectedIndex();
		int addedToppingListSize = addedToppingsList.getModel().getSize();

		//System.out.println(addedToppingListSize);
		//System.out.println(indexToRemove);
		if (indexToRemove >= 0) {
			addedToppings.remove(indexToRemove);
			//System.out.println(addedToppingListSize);
			addedToppingsList.revalidate();
			updateToppingsList();
		} else {
			JOptionPane.showMessageDialog(this,
					"Select a topping from the list above first.");
		}
		updateToppingsList();

	}

	/**
	 * STEP 2 is all about setting the local variable toppingSide to the left,
	 * whole or right. This is used to determine price.
	 * 
	 */
	// ********************* Step 2 - Begin Adding Toppings END*****//.
	/**
	 * Sets toppingSide for left side of pizza selector button.
	 */
	private void leftRButtonActionPerformed(ActionEvent evt) {
		toppingSide = domain.Item.TSide.LEFT;
	}

	/**
	 * Sets toppingSide for whole pizza when selector button all.
	 * 
	 * @param evt
	 */
	private void wholeRButtonActionPerformed(ActionEvent evt) {
		toppingSide = domain.Item.TSide.ALL;
	}

	/**
	 * Sets toppingSide to right side for pizza selector button right.
	 * 
	 * @param evt
	 */
	private void rightRButtonActionPerformed(ActionEvent evt) {
		toppingSide = domain.Item.TSide.RIGHT;
	}

	// /************* ADD / CANCEL PIZZA CREATION **************//
	/**
	 * Checks for the size. Depending on the size, a clone of that size pizza is
	 * brought up. The toppings are added to that pizza item and then voila, the
	 * pizza is created.
	 * 
	 * @param evt
	 */
	private void addPizzaButtonActionPerformed(java.awt.event.ActionEvent evt) {
		Item thePizza = null;

		thePizza = itemType.clone();
		for (Tuple<String, TSide> i : addedToppings) {
			if (i.second == Item.TSide.ALL) {
				thePizza.addTopping(i.first, prices[pizzaSize], i.second);
			} else {
				thePizza.addTopping(i.first, prices[pizzaSize] / 2, i.second);
			}
		}

		// Integrating Quantity of pizzas spinner (name: quantityPizzasSpinner )
		for (int i = 0; i < (Integer) quantityPizzasSpinner.getValue(); i++) {
			// Cloneing thePizza
			// ---------------------------------------------------<xxxxDOWN
			((CreateOrderDialog) this.getParent()).addItemToOrder(thePizza
					.clone());
		}

		this.dispose();
	}

	/**
	 * Pizza never created, closes this frame
	 * 
	 * @param evt
	 */
	private void cancelNewPizzaButtonActionPerformed(
			java.awt.event.ActionEvent evt) {
		this.dispose();
	}

	// GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JLabel addNewPizzaMenuTitleLabel;
	private javax.swing.JButton addPizzaButton;
	private javax.swing.JButton addToppingButton;
	private javax.swing.JList addedToppingsList;
	private javax.swing.JButton cancelNewPizzaButton;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JRadioButton leftRButton;
	private javax.swing.JSpinner quantityPizzasSpinner;
	private javax.swing.JButton removeToppingButton;
	private javax.swing.JRadioButton rightRButton;
	private javax.swing.JPanel selectQuantityPanel;
	private javax.swing.JPanel selectToppingsPanel;
	private javax.swing.ButtonGroup topping1ButtonGroup;
	private javax.swing.JComboBox toppingsDropDown;
	private javax.swing.JRadioButton wholeRButton;
	// End of variables declaration//GEN-END:variables

}