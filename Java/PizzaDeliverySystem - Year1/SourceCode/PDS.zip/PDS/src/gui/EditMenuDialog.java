/*
 * EditMenuDialog.java
 *
 * Created on __DATE__, __TIME__
 */

package gui;

import java.awt.event.ActionEvent;
import java.io.IOException;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

import data.ItemTracker;
import domain.Item;

/**
 * Generates an edit menu window.
 * 
 * @author acc, kxc
 */
public class EditMenuDialog extends javax.swing.JDialog {

	/** Creates new form EditMenuDialog */
	public EditMenuDialog(java.awt.Frame parent, boolean modal) {
		super(parent, modal);
		initComponents();
		setupTable();
		this.setLocationRelativeTo(null);
	}

	/**
	 * this method sets up the table by setting a custom default model to the
	 * backend.
	 */
	private void setupTable() {
		itemTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		itemTable.setModel(new gui.model.ItemTableModel());
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jScrollPane1 = new javax.swing.JScrollPane();
		itemTable = new javax.swing.JTable();
		addItemButton = new javax.swing.JButton();
		editItemButton = new javax.swing.JButton();
		deleteItemButton = new javax.swing.JButton();
		backButton = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
		setTitle("Store Menu - Add/Edit/Delete Items");

		jScrollPane1.setViewportView(itemTable);

		addItemButton.setFont(new java.awt.Font("Segoe UI", 0, 35));
		addItemButton.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/Icons/Add.png"))); // NOI18N
		addItemButton.setText("Add Item");
		addItemButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				addItemButtonActionPerformed(evt);
			}
		});

		editItemButton.setFont(new java.awt.Font("Segoe UI", 0, 35));
		editItemButton.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/Edit.png"))); // NOI18N
		editItemButton.setText("Edit Item");
		editItemButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				editItemButtonActionPerformed(evt);
			}
		});

		deleteItemButton.setFont(new java.awt.Font("Segoe UI", 0, 35));
		deleteItemButton.setIcon(new javax.swing.ImageIcon(getClass()
				.getResource("/Icons/onebit_32.png"))); // NOI18N
		deleteItemButton.setText("Delete Item");
		deleteItemButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				deleteItemButtonActionPerformed(evt);
			}
		});

		backButton.setFont(new java.awt.Font("Segoe UI", 0, 40));
		backButton.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/Icons/onebit_29.png"))); // NOI18N
		backButton.setText("Back");
		backButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				backButtonActionPerformed(evt);
			}
		});

		jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 40));
		jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/Icons/onebit_14.png"))); // NOI18N
		jLabel1.setText("Menu");

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						layout.createSequentialGroup()
								.addContainerGap()
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(
														jLabel1,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														295, Short.MAX_VALUE)
												.addComponent(
														jScrollPane1,
														javax.swing.GroupLayout.PREFERRED_SIZE,
														295,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(
										javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(
														editItemButton,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														265, Short.MAX_VALUE)
												.addComponent(
														deleteItemButton,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														265, Short.MAX_VALUE)
												.addComponent(
														addItemButton,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														265, Short.MAX_VALUE)
												.addComponent(
														backButton,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														265, Short.MAX_VALUE))
								.addContainerGap()));
		layout.setVerticalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						layout.createSequentialGroup()
								.addContainerGap()
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(
														layout.createSequentialGroup()
																.addComponent(
																		addItemButton,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		110,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(
																		editItemButton,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		110,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(
																		deleteItemButton,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		110,
																		javax.swing.GroupLayout.PREFERRED_SIZE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(
																		backButton,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		89,
																		Short.MAX_VALUE))
												.addGroup(
														javax.swing.GroupLayout.Alignment.TRAILING,
														layout.createSequentialGroup()
																.addComponent(
																		jLabel1,
																		javax.swing.GroupLayout.DEFAULT_SIZE,
																		58,
																		Short.MAX_VALUE)
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																.addComponent(
																		jScrollPane1,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		375,
																		javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addContainerGap()));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	/**
	 * DELETE ITEM BUTTON Deletes the selected item. refreshes the list after
	 * deletion.
	 * 
	 * @param evt
	 */
	private void deleteItemButtonActionPerformed(java.awt.event.ActionEvent evt) {
		int selection = itemTable.getSelectedRow();
		if (selection >= 0
				&& selection < ItemTracker.getInstance().getData().size()) {
			ItemTracker.getInstance().getData().remove(selection);
			itemTable.setModel(new gui.model.ItemTableModel());// /REVALIDATING!
			itemTable.revalidate();
		} else {
			JOptionPane.showMessageDialog(this,
					"Select an Item from the left first please.");
		}
		itemTable.setModel(new gui.model.ItemTableModel());// /REVALIDATING!
		itemTable.revalidate();
	}

	/**
	 * ADD ITEM BUTTON
	 * 
	 * Launches the new item wizard dialog screen. make sures to revalidate item
	 * list constantly.
	 * 
	 * @param evt
	 */
	protected void addItemButtonActionPerformed(ActionEvent evt) {
		JDialog d = new CreateItemDialog(this, true);
		d.pack();
		d.setVisible(true);
		itemTable.revalidate();
		itemTable.setModel(new gui.model.ItemTableModel()); // /REVALIDATING!
	}

	/**
	 * EDIT ITEM BUTTON Launches the new item wizard but is used as editing the
	 * selected item.
	 * 
	 * @param evt
	 */
	private void editItemButtonActionPerformed(java.awt.event.ActionEvent evt) {
		int selection = itemTable.getSelectedRow();
		itemTable.revalidate();
		itemTable.setModel(new gui.model.ItemTableModel()); // /REVALIDATING!
		if (selection >= 0
				&& selection < ItemTracker.getInstance().getData().size()) {
			Item item = ItemTracker.getInstance().getData().get(selection);
			JDialog d = new CreateItemDialog(this, true, item);
			d.setVisible(true);
			itemTable.setModel(new gui.model.ItemTableModel()); // /REVALIDATING!
			itemTable.revalidate();

		} else {
			JOptionPane.showMessageDialog(this,
					"Must select one item from the list first!");
		}
	}

	/**
	 * BACK BUTTON Makes sure to revalidate, and then close this frame.
	 * 
	 * @param evt
	 */
	private void backButtonActionPerformed(java.awt.event.ActionEvent evt) {
		this.setVisible(false);
		this.dispose();
		itemTable.revalidate();
		itemTable.setModel(new gui.model.ItemTableModel());// /REVALIDATING!
	}

	/**
	 * Mini mtehod to return the JTable.
	 * 
	 * @return JTable
	 */
	public JTable getItemTable() {

		return itemTable;
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton addItemButton;
	private javax.swing.JButton backButton;
	private javax.swing.JButton deleteItemButton;
	private javax.swing.JButton editItemButton;
	private javax.swing.JTable itemTable;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JScrollPane jScrollPane1;
	// End of variables declaration//GEN-END:variables

}