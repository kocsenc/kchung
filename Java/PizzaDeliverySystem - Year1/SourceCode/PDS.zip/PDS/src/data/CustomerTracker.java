package data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

import domain.Customer;

/**
 * CustomerTracker tracks known customer information and saves it to file.
 * 
 * @author acc3863
 * 
 */
public class CustomerTracker implements DataTracker<Customer> {
	private static CustomerTracker instance = new CustomerTracker();
	private static String CUSTOMER_FILE = "customers.dat";

	private List<Customer> customers;

	/**
	 * Maintains a list of known customers that have ordered in the past.
	 */
	private CustomerTracker() {
		this.customers = new ArrayList<Customer>();
	}

	/**
	 * Setter for CUSTOMER_FILE if given in main as an argument.
	 * 
	 * @param fileName
	 */
	public static void setLoadFile(String fileName) {
		CUSTOMER_FILE = fileName;
	}

	/**
	 * Loads previous customer data from the customer file.
	 * 
	 * @throws IOException
	 *             - IOException occurred while reading customers.dat.
	 */
	@Override
	public void loadFromFile() throws IOException {
		File cfile = new File(CUSTOMER_FILE);
		if (cfile.exists()) {
			Scanner scn = new Scanner(new FileInputStream(cfile));
			scn.useDelimiter(DataTracker.SEPARATOR);
			try {
				while (scn.hasNext()) {
					String name = scn.next();
					String phone = scn.next();
					Customer i = new Customer(name, phone);
					addData(i);
				}
			} catch (NoSuchElementException nse) {
				throw new IOException("Corrupted file: " + CUSTOMER_FILE);
			}
			scn.close();
		} else {
			cfile.createNewFile();
		}
	}

	/**
	 * Saves all customers to the customer data file.
	 */
	@Override
	public void saveToFile() throws IOException {
		File cfile = new File(CUSTOMER_FILE);
		FileWriter fw = new FileWriter(cfile);
		for (Customer i : customers) {
			fw.write(i.getName() + DataTracker.SEPARATOR);
			fw.write(i.getPhone() + DataTracker.SEPARATOR);
		}
		fw.close();
	}

	/**
	 * Returns the list of customers.
	 * 
	 * @return the list of customers.
	 */
	@Override
	public List<Customer> getData() {
		return customers;
	}

	/**
	 * Adds a customer to the list of customers.
	 */
	@Override
	public void addData(Customer cust) {
		customers.add(cust);
	}

	/**
	 * Returns the static singleton instance of CustomerTracker.
	 * 
	 * @return the static singleton instance of CustomerTracker.
	 */
	public static CustomerTracker getInstance() {
		return instance;
	}

	/**
	 * PRECONDITION: lookup String is not empty - POSTCONDITION: Looks up for a
	 * customer. Returns its instance if its found, else returns null.
	 * 
	 * @param lookupString
	 *            - phone or name to look up by.
	 * @return instance of found customer, else returns null if no customer was
	 *         found.
	 */
	public Customer getCustomer(String lookupString) {
		if (customers.size() < 1 || lookupString.isEmpty()) {
			return null;
		}
		for (int i = 0; i < customers.size(); i++) {
			if (customers.get(i).getPhone().equalsIgnoreCase(lookupString)
					|| customers.get(i).getName()
							.equalsIgnoreCase(lookupString)) {
				return customers.get(i);
			}
		}
		return null;

	}
}
