package data;

import gui.model.Tuple;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.lang.Math;
import domain.Order;

/**
 * StatisticsTracker manages the data to form the manager reports.
 * 
 * @author acc3863
 */
public class StatisticsTracker {
	private static StatisticsTracker instance = new StatisticsTracker();
	private static String STATS_FILE = "stats.dat";

	private int dailyOrders; // 1
	private int totalOrders; // 2
	private float averageOrderCost;// 3
	private float averagePrePrepTime;// 4
	private Tuple<Integer, Integer> maxPrePrepTime; // 5
	private float averagePreDeliverTime; // 6
	private Tuple<Integer, Integer> maxPreDeliverTime;// 7
	private float averageTotalTime;// 8
	private Tuple<Integer, Integer> maxTotalTime;// 9

	private StatisticsTracker() {
		dailyOrders = 0;
		maxPrePrepTime = new Tuple<Integer, Integer>(-1, -1);
		maxPreDeliverTime = new Tuple<Integer, Integer>(-1, -1);
		maxTotalTime = new Tuple<Integer, Integer>(-1, -1);
	}

	/**
	 * recordStats takes order objects and generates the statistics necessary to
	 * produce manager reports
	 * 
	 * @param Order
	 *            object
	 */
	public void recordStats(Order order) {
		// System.out.println("Recording Stats");
		// System.out.println("AVG pre prep time: " + averagePrePrepTime);

		// totalTime: Correct
		int totalTime = order.getTimeDelivered() - order.getTimePlaced();
		/*
		 * System.out.println("totalTime = " + totalTime + " = " +
		 * String.valueOf(order.getTimeDelivered()) + " - " +
		 * String.valueOf(order.getTimePlaced()) + " CORRECT!");
		 */

		// This preKTime seems to be the buggy problem:
		int preKTime = Math.abs(order.getTimeKitchenStart()
				- order.getTimeKitchenSubmit());

		/*
		 * System.out.println("PreKTime = |" + preKTime + " = " +
		 * String.valueOf(order.getTimeKitchenStart()) + " - " +
		 * String.valueOf(order.getTimeKitchenSubmit()) + "|");
		 */

		// This preDTime also seems to be a problem.
		int preDTime = Math.abs(order.getTimeDeliverSubmit()
				- order.getTimeDeliverSubmit());
		// System.out.println("PreDTime = " + preDTime
		// + " = order.getTimeDeliverSubmit()");

		if (totalTime > maxTotalTime.first) {
			maxTotalTime.first = totalTime;
			maxTotalTime.second = order.getId();
		}
		if (preKTime > maxPrePrepTime.first) {
			maxPrePrepTime.first = preKTime;
			maxPrePrepTime.second = order.getId();
		}
		if (preDTime > maxPreDeliverTime.first) {
			maxPreDeliverTime.first = preDTime;
			maxPreDeliverTime.second = order.getId();
		}
		averageOrderCost = (float) (((averageOrderCost * (totalOrders - 1)) + order
				.getPrice()) / (totalOrders));

		averagePrePrepTime = (float) (((averagePrePrepTime * (totalOrders - 1)) + preKTime) / (totalOrders));
		/*System.out.println("Calculating Average pre prep time = "
				+ String.valueOf(averagePrePrepTime) + " =  (("
				+ String.valueOf(averagePrePrepTime) + " * ("
				+ String.valueOf(totalOrders) + " - 1)) + "
				+ String.valueOf(preKTime) + ") / ("
				+ String.valueOf(totalOrders) + "))");*/

		averagePreDeliverTime = (float) (((averagePreDeliverTime * (totalOrders - 1)) + preDTime) / (totalOrders));
		averageTotalTime = (float) (((averageTotalTime * (totalOrders - 1)) + totalTime) / (totalOrders));
	}

	/**
	 * Loads previous StatisticsTracker data from the data file.
	 * 
	 * @throws IOException
	 *             - Error in reading from file.
	 */
	// @Override
	public void loadFromFile() throws IOException {
		File cfile = new File(STATS_FILE);
		if (cfile.exists()) {
			Scanner scn = new Scanner(new FileInputStream(cfile));
			scn.useDelimiter(DataTracker.SEPARATOR);
			try {
				totalOrders = scn.nextInt();
				averageOrderCost = scn.nextFloat();
				averagePrePrepTime = scn.nextFloat();
				int maxPrePrepTime0 = scn.nextInt();
				int maxPrePrepTime1 = scn.nextInt();
				maxPrePrepTime = new Tuple<Integer, Integer>(maxPrePrepTime0,
						maxPrePrepTime1);
				averagePreDeliverTime = scn.nextFloat();
				int maxPreDeliverTime0 = scn.nextInt();
				int maxPreDeliverTime1 = scn.nextInt();
				maxPreDeliverTime = new Tuple<Integer, Integer>(
						maxPreDeliverTime0, maxPreDeliverTime1);
				averageTotalTime = scn.nextFloat();
				int maxTotalTime0 = scn.nextInt();
				int maxTotalTime1 = scn.nextInt();
				maxTotalTime = new Tuple<Integer, Integer>(maxTotalTime0,
						maxTotalTime1);
			} catch (NoSuchElementException nse) {
				throw new IOException("Corrupted file: " + STATS_FILE);
			}
			scn.close();
		} else {
			cfile.createNewFile();
		}
		// System.out.println("Loaded with OID: " + totalOrders);
	}

	/**
	 * Saves current statistics to file.
	 * 
	 * @throws IOException
	 *             - Error in writing to file.
	 */
	// @Override
	public void saveToFile() throws IOException {
		File cfile = new File(STATS_FILE);
		FileWriter fw = new FileWriter(cfile);
		fw.write(totalOrders + DataTracker.SEPARATOR);
		fw.write(averageOrderCost + DataTracker.SEPARATOR);
		fw.write(averagePrePrepTime + DataTracker.SEPARATOR);
		fw.write(maxPrePrepTime.first + DataTracker.SEPARATOR);
		fw.write(maxPrePrepTime.second + DataTracker.SEPARATOR);
		fw.write(averagePreDeliverTime + DataTracker.SEPARATOR);
		fw.write(maxPreDeliverTime.first + DataTracker.SEPARATOR);
		fw.write(maxPreDeliverTime.second + DataTracker.SEPARATOR);
		fw.write(averageTotalTime + DataTracker.SEPARATOR);
		fw.write(maxTotalTime.first + DataTracker.SEPARATOR);
		fw.write(maxTotalTime.second + DataTracker.SEPARATOR);
		fw.close();
	}

	/**
	 * @return the dailyOrders
	 */
	public int getDailyOrders() {
		return dailyOrders;
	}

	/**
	 * @return the totalOrders
	 */
	public int getTotalOrders() {
		return totalOrders;
	}

	/**
	 * @return the averageOrderCost
	 */
	public float getAverageOrderCost() {
		return averageOrderCost;
	}

	/**
	 * @return the averagePrePrepTime
	 */
	public float getAveragePrePrepTime() {
		return averagePrePrepTime;
	}

	/**
	 * @return the maxPrePrepTime
	 */
	public Tuple<Integer, Integer> getMaxPrePrepTime() {
		return maxPrePrepTime;
	}

	/**
	 * @return the averagePreDeliverTime
	 */
	public float getAveragePreDeliverTime() {
		return averagePreDeliverTime;
	}

	/**
	 * @return the maxPreDeliverTime
	 */
	public Tuple<Integer, Integer> getMaxPreDeliverTime() {
		return maxPreDeliverTime;
	}

	/**
	 * @return the averageTotalTime
	 */
	public float getAverageTotalTime() {
		return averageTotalTime;
	}

	/**
	 * @return the maxTotalTime
	 */
	public Tuple<Integer, Integer> getMaxTotalTime() {
		return maxTotalTime;
	}

	/**
	 * 
	 * @return totalOrders incremented
	 */
	public int getNextOrderID() {
		dailyOrders++;
		return totalOrders++;
	}

	/**
	 * 
	 * @return instance of StatisticsTracker
	 */
	public static StatisticsTracker getInstance() {
		return instance;
	}
}
