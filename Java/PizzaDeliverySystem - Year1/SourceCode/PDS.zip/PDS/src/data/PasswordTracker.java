package data;

import gui.ManagerFrame;
import java.io.*;

import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;
/*
 * PasswordTracker manages the saving, changing and loading of passwords
 * in the PDS.
 */
public class PasswordTracker {

	private static PasswordTracker instance = new PasswordTracker();
	static char[] password;
	private static String PASSWORD_FILE = "password.dat";

	public static void loadFile(String fileName) {
		PASSWORD_FILE = fileName;
	}
/*
 * loadFromFile takes the password data and writes it to 
 * a character array.
 */
	@SuppressWarnings("resource")
	public void loadFromFile() throws IOException {
		File passFile = new File(PASSWORD_FILE);
		if (passFile.exists()) {

			Scanner s = new Scanner(new FileInputStream(passFile));
			try {
				if (s.hasNext()) {
					password = s.next().toCharArray();

				} else {
					password = "master".toCharArray();
					System.out
							.println("Password File Corrupt: Password has reset to master password");
				}

			} catch (NoSuchElementException e) {
				throw new IOException("corrupted file: " + e.getMessage());
			}
			s.close();

		} else {
			passFile.createNewFile();
			FileWriter writer = new FileWriter(passFile);
			writer.write("master");
			password = "master".toCharArray();
		}

	}

	/**
	 * writeToFile takes the character input and writes the password
	 * to file.
	 * @param newPassword
	 */
	private static void writeToFile(char[] newPassword) {
		File passFile = new File(PASSWORD_FILE);
		try {
			FileWriter writer = new FileWriter(passFile);
			// Scanner s = new Scanner(new FileInputStream(passFile));

			writer.write(new String(password)); // Write new password onto file.

			writer.close();

		} catch (Exception e) {
			System.err.println("Fatal Error in writing password: "
					+ e.getMessage());
		}

	}

	/**
	 * Method that checks if old password is correct and if both new passwords
	 * match one another. If they do then the password is changed it returns
	 * true; if they dont, it return false
	 * 
	 * @param oldPass
	 *            - old pass to change
	 * @param newPass1
	 *            - new password
	 * @param newPass2
	 *            - new password confirmation
	 * @return
	 */
	public static boolean canChangePassword(char[] oldPass, char[] newPass1,
			char[] newPass2) {
		if (Arrays.equals(password, oldPass)
				&& Arrays.equals(newPass1, newPass2)) {
			changePassword(newPass1);

			return true;
		} else {
			return false;
		}
	}

	/**
	 * Method called to actually change the password. set sthe local variable
	 * password to the new password, and then writes the new password to the
	 * password.dat file to reload on next startup.
	 * 
	 * @param newPassword
	 *            - the new master password.
	 */
	private static void changePassword(char[] newPassword) {
		password = newPassword;
		writeToFile(password);
	}

	/**
	 * returns password
	 * 
	 * @return password - a char array of the password. Reason why its a char
	 *         array: password dialogs get the user input data as a char array.
	 *         Hence, password is a char array for Array compraisons.
	 */
	public static char[] getPassword() {
		return password;
	}

	/**
	 * Used to access any of these methods, as this is a singleton Class.
	 * 
	 * @return - The instance of this PasswordTracker.
	 */
	public static PasswordTracker getInstance() {
		return instance;
	}

	/**
	 * Called upon shut down. It ensures that the latest password is written to
	 * the file so that on next startup, the password is accurate.
	 */
	public static void safeShutdown() {
		writeToFile(password);

	}

}
