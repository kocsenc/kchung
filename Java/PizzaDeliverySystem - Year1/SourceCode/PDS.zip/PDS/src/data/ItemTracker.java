package data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

import domain.Item;

/**
 * Maintains a list of available item options for ordering.
 * 
 * @author acc3863
 * 
 */
public class ItemTracker implements DataTracker<Item> {
	private static ItemTracker instance = new ItemTracker();
	private static String ITEM_FILE = "items.dat";
	private List<Item> itemOptions;

	/**
	 * Creates an ItemTracker instance with no items tracked.
	 */
	private ItemTracker() {
		itemOptions = new ArrayList<Item>();
		//DEFAULT PIZZAS
		itemOptions.add(new Item("Small Pizza", 8f, 8, 13, 1, true));
		itemOptions.add(new Item("Medium Pizza", 11f, 10, 15, 2, true));
		itemOptions.add(new Item("Large Pizza", 16f, 15, 20, 4, true));
	}

	/**
	 * Setter for ITEM_FILE if given in main as an argument.
	 * 
	 * @param fileName
	 */
	public static void setLoadFile(String fileName) {
		ITEM_FILE = fileName;
	}

	/**
	 * Loads items from the data file.
	 * 
	 * @throws IOException
	 *             - IOException occurred while reading items.dat.
	 */
	@Override
	public void loadFromFile() throws IOException {
		File cfile = new File(ITEM_FILE);
		if (cfile.exists()) {
			Scanner scn = new Scanner(new FileInputStream(cfile));
			scn.useDelimiter(DataTracker.SEPARATOR);
			try {
				while (scn.hasNext()) {
					String name = scn.next();
					float price = scn.nextFloat();
					int prep = scn.nextInt();
					int cook = scn.nextInt();
					int space = scn.nextInt();
					boolean top = scn.nextBoolean();
					Item i = new Item(name, price, prep, cook, space, top);
					addData(i);
				}
			} catch (NoSuchElementException nse) {
				throw new IOException("Corrupted file: " + ITEM_FILE);
			}
			scn.close();
		} else {
			cfile.createNewFile();
		}
	}

	/**
	 * Saves item to the data file.
	 * 
	 * @throws IOException
	 *             - IOException occured while reading items.dat.
	 */
	@Override
	public void saveToFile() throws IOException {
		File cfile = new File(ITEM_FILE);
		FileWriter fw = new FileWriter(cfile);
		for (Item i : itemOptions) {
			fw.write(i.getName() + DataTracker.SEPARATOR);
			fw.write(i.getPrice() + DataTracker.SEPARATOR);
			fw.write(i.getPrepTime() + DataTracker.SEPARATOR);
			fw.write(i.getCookTime() + DataTracker.SEPARATOR);
			fw.write(i.getOvenSpace() + DataTracker.SEPARATOR);
			fw.write(i.hasToppings() + DataTracker.SEPARATOR);
		}
		fw.close();
	}

	/**
	 * Returns the item options.
	 * 
	 * @return the item options.
	 */
	@Override
	public List<Item> getData() {
		return itemOptions;
	}

	/**
	 * Adds an item to the item options if the item is not already contained.
	 */
	@Override
	public void addData(Item data) {
		if (!itemOptions.contains(data))
			itemOptions.add(data);
	}

	/**
	 * Returns the first item found with the passed name, null if not found.
	 * 
	 * @param name
	 *            - the name
	 * @return the first item found, null if not found.
	 */
	public Item lookupByName(String name) {
		for (Item i : getData()) {
			if (i.getName().equals(name)) {
				return i;
			}
		}
		return null;
	}

	/**
	 * Returns the first item found containing the passed name, null if not
	 * found.
	 * 
	 * @param search
	 * @return the first item found, null if not found.
	 */
	public Item lookupByNameContains(String search) {
		for (Item i : getData()) {
			if (i.getName().contains(search)) {
				return i;
			}
		}
		return null;
	}

	/**
	 * Returns the static singleton instance of ItemTracker.
	 * 
	 * @return the static singleton instance of ItemTracker.
	 */
	public static ItemTracker getInstance() {
		return instance;
	}

}
