package data;

import java.io.IOException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JFrame;

import cli.CLControl;

/**
 * Launches the application by parsing data file args provided by user or using
 * default data files.
 * 
 * @author cpk4877
 */

public class Main {
	/**
	 * handleArgs parses the args list to load files provided, or default files
	 * if none given.
	 */

	private static void handleArgs(String[] args) {
		List<String> argsList = new ArrayList<String>(Arrays.asList(args));

		if (argsList.contains("-cli")) {
			argsList.remove("-cli");
			if (argsList.size() > 0) { // read the rest of args, if any...
				if (argsList.contains("-i")) { // if given an item file load it
					int fileIndex = argsList.indexOf("-i") + 1;
					ItemTracker.setLoadFile(argsList.get(fileIndex));
				} else { // else load default file
					try {
						ItemTracker.getInstance().loadFromFile();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if (argsList.contains("-o")) { // if given an order file load it
					int fileIndex = argsList.indexOf("-o") + 1;
					OrderTracker.setLoadFile(argsList.get(fileIndex));
				} else { // else load default file
					try {
						OrderTracker.getInstance().loadFromFile();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if (argsList.contains("-c")) { // if given customer file load it
					int fileIndex = argsList.indexOf("-c") + 1;
					CustomerTracker.setLoadFile(argsList.get(fileIndex));
				} else {
					try {
						CustomerTracker.getInstance().loadFromFile(); // else
																		// load
																		// default
																		// file
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if (argsList.contains("-t")) {
					int index = argsList.indexOf("-t") + 1;
					try {
						int delay = Integer.parseInt(argsList.get(index));
						System.out.println("Using delay of: " + delay + "ms");
						if (delay <= 0) {
							System.err.println("Invalid delay time.");
							return;
						}
						OrderTracker.getInstance().getTimeTicker()
								.setDelay(delay);
					} catch (NumberFormatException nfe) {
						System.err.println("Invalid delay time.");
						return;
					}
				}
				// System.out.println("Starting CLI");
				loadFiles();
				CLControl control = new CLControl();
				control.startCLI();
				System.exit(0); // why do I need to do this...
			} else {
				// System.out.println("Starting CLI");
				loadFiles();
				CLControl control = new CLControl();
				control.startCLI();
				System.exit(0); // why do I need to do this...
			}
		} else if (argsList.contains("-gui")) {
			argsList.remove("-gui");
			if (argsList.size() > 0) {
				if (argsList.contains("-i")) { // if given an item file load it
					int fileIndex = argsList.indexOf("-i") + 1;
					ItemTracker.setLoadFile(argsList.get(fileIndex));
				} else { // else load default file
					try {
						ItemTracker.getInstance().loadFromFile();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if (argsList.contains("-o")) { // if given an order file load it
					int fileIndex = argsList.indexOf("-o") + 1;
					OrderTracker.setLoadFile(argsList.get(fileIndex));
				} else { // else load default file
					try {
						OrderTracker.getInstance().loadFromFile();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if (argsList.contains("-c")) { // if given customer file load it
					int fileIndex = argsList.indexOf("-c") + 1;
					CustomerTracker.setLoadFile(argsList.get(fileIndex));
				} else {
					try {
						CustomerTracker.getInstance().loadFromFile(); // else
																		// load
																		// default
																		// file
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if (argsList.contains("-t")) {
					int index = argsList.indexOf("-t") + 1;
					try {
						int delay = Integer.parseInt(argsList.get(index));
						System.out.println("Using delay of: " + delay + "ms");
						if (delay <= 0) {
							System.err.println("Invalid delay time.");
							return;
						}
						OrderTracker.getInstance().getTimeTicker()
								.setDelay(delay);
					} catch (NumberFormatException nfe) {
						System.err.println("Invalid delay time.");
						return;
					}
				}
				loadFiles();
				java.awt.EventQueue.invokeLater(new Runnable() {
					public void run() {
						JFrame j = new gui.DayStartFrame();
						j.setVisible(true);
					}
				});
			} else {
				
				// System.out.println("Starting GUI");
				loadFiles();
				java.awt.EventQueue.invokeLater(new Runnable() {
					public void run() {
						JFrame j = new gui.DayStartFrame();
						j.setVisible(true);
					}
				});
			}
		} else {
			if (argsList.contains("-i")) { // if given an item file load it
				int fileIndex = argsList.indexOf("-i") + 1;
				ItemTracker.setLoadFile(argsList.get(fileIndex));
			} else { // else load default file
				try {
					ItemTracker.getInstance().loadFromFile();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (argsList.contains("-o")) { // if given an order file load it
				int fileIndex = argsList.indexOf("-o") + 1;
				OrderTracker.setLoadFile(argsList.get(fileIndex));
			} else { // else load default file
				try {
					OrderTracker.getInstance().loadFromFile();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (argsList.contains("-c")) { // if given customer file load it
				int fileIndex = argsList.indexOf("-c") + 1;
				CustomerTracker.setLoadFile(argsList.get(fileIndex));
			} else {
				try {
					CustomerTracker.getInstance().loadFromFile(); // else
																	// load
																	// default
																	// file
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (argsList.contains("-t")) {
				int index = argsList.indexOf("-t") + 1;
				try {
					int delay = Integer.parseInt(argsList.get(index));
					System.out.println("Using delay of: " + delay + "ms");
					if (delay <= 0) {
						System.err.println("Invalid delay time.");
						return;
					}
					OrderTracker.getInstance().getTimeTicker()
							.setDelay(delay);
				} catch (NumberFormatException nfe) {
					System.err.println("Invalid delay time.");
					return;
				}
			}
			loadFiles();
			java.awt.EventQueue.invokeLater(new Runnable() {
				public void run() {
					JFrame j = new gui.DayStartFrame();
					j.setVisible(true);
				}
			});
		}
	}

	/**
	 * Loads all tracker data from files.
	 */
	private static void loadFiles() {
		try {
			ItemTracker.getInstance().loadFromFile();
		} catch (IOException e) {
		}

		try {
			OrderTracker.getInstance().loadFromFile();
		} catch (IOException e) {
		}

		try {
			CustomerTracker.getInstance().loadFromFile();
		} catch (IOException e) {
		}

		try {
			PasswordTracker.getInstance().loadFromFile();
		} catch (IOException e) {
		}

		try {
			StatisticsTracker.getInstance().loadFromFile();
		} catch (IOException e) {
		}
	}

	/**
	 * Starts a normal run of the PDS system.
	 * 
	 * @param args
	 * @throws Throwable
	 */
	public static void main(String[] args) throws Throwable {

		if (args.length > 0) { // startup with args
			handleArgs(args);
		} else { // no args startup
			loadFiles();
			java.awt.EventQueue.invokeLater(new Runnable() {
				public void run() {
					JFrame j = new gui.DayStartFrame();
					j.setVisible(true);
				}
			});
		}
	}

	/**
	 * shutDown ends the day and saves order, statistics and customer data.
	 */
	public static void shutDown() {
		OrderTracker.getInstance().endDay();
		try {
			OrderTracker.getInstance().saveToFile();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
		try {
			StatisticsTracker.getInstance().saveToFile();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
		try {
			CustomerTracker.getInstance().saveToFile();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
	}
}
