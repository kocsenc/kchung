package data;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

import javax.swing.Timer;

import domain.DeliveryStation;
import domain.Item;
import domain.KitchenStation;
import domain.Order;
import domain.OrderStatus;

/**
 * The OrderTracker class tracks Orders as they progress through the preparation
 * process. Additionally, it provides an external interface through which the
 * rest of the pizza delivery system accesses order information.
 * 
 * @author acc3863
 * 
 */
public class OrderTracker implements DataTracker<Order> {
	private static String ORDER_FILE = "orders.dat";
	private static OrderTracker instance = new OrderTracker();

	private List<Order> activeOrders;
	private List<Order> deadOrders;
	private List<Item> cancelItemPool;
	private KitchenStation kitchen;
	private DeliveryStation delivery;
	private Timer timeTicker;
	private boolean dayRunning;
	private boolean readyToStart;
	private int chefs;
	private int ovens;
	private int ovenSpace;
	private int cars;
	private int totalTime;

	/**
	 * Instantiates an OrderTracker object with no orders tracked.
	 */
	private OrderTracker() {
		totalTime = 0;
		chefs = 1;
		ovens = 1;
		ovenSpace = 1;
		cars = 1;
		activeOrders = new ArrayList<Order>();
		deadOrders = new ArrayList<Order>();
		cancelItemPool = new ArrayList<Item>();
		dayRunning = false;
		readyToStart = false;
		timeTicker = new Timer(1000, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				kitchen.tick();
				updateOrders();
				delivery.tick();
				totalTime++;
			}

		});
		timeTicker.setDelay(1000);
		timeTicker.setInitialDelay(0);
		timeTicker.setRepeats(true);
	}

	/**
	 * Initializes the different stations of an OrderTracker with employees.
	 * 
	 * @param chefs
	 *            - The number of chefs.
	 * @param ovens
	 *            - The number of ovens.
	 * @param ovenspace
	 *            - The amount of space per oven.
	 * @param cars
	 *            - The number of delivery cars.
	 */
	public void initStations(int chefs, int ovens, int ovenspace, int cars) {
		this.chefs = chefs;
		this.ovens = ovens;
		this.ovenSpace = ovenspace;
		this.cars = cars;
		readyToStart = true;
	}

	/**
	 * Setter for ORDER_FILE if given in main as an argument.
	 * 
	 * @param fileName
	 */
	public static void setLoadFile(String fileName) {
		ORDER_FILE = fileName;
	}

	/**
	 * Starts the Timer member, emitting an event every 1000ms to simulate time
	 * passing and the day starting.
	 */
	public void startDay() {
		if (readyToStart) {
			kitchen = new KitchenStation(chefs, ovens, ovenSpace);
			delivery = new DeliveryStation(cars);
			timeTicker.start();
			dayRunning = true;
		}
	}

	public Timer getTimeTicker() {
		return timeTicker;
	}

	/**
	 * Returns true if the pizza store is running.
	 * 
	 * @return true if the pizza store is running.
	 */
	public boolean isDayRunning() {
		return dayRunning;
	}

	/**
	 * Returns true if the pizza store is ready to start running.
	 * 
	 * @return true if the pizza store is ready to run.
	 */
	public boolean isReadyToStart() {
		return readyToStart;
	}

	/**
	 * Ends the day at the pizza store, stopping the Timer.
	 */
	public void endDay() {
		timeTicker.stop();
		dayRunning = false;
	}

	/**
	 * Updates the states of all orders tracked by this OrderTracker.
	 */
	public void updateOrders() {
		Iterator<Order> iter = activeOrders.listIterator();
		while (iter.hasNext()) {
			Order o = iter.next();
			if (o.getStatus() == OrderStatus.IN_PREP) {
				boolean allDone = true;
				for (Item i : o.getItems()) {
					if (!i.isPrepared()) {
						allDone = false;
						break;
					}
				}
				if (allDone) {
					o.setStatus(OrderStatus.AWAITING_TRANSIT);
					o.setTimeDeliverStart(totalTime);
					delivery.deliverOrder(o);
				}
			} else if (o.getStatus() == OrderStatus.DELIVERED) {
				o.setTimeDelivered(totalTime);
				StatisticsTracker.getInstance().recordStats(o);
				iter.remove();
				deadOrders.add(o);
			}
		}
	}

	/**
	 * Submits an order to the KitchenStation object for preparation and
	 * cooking, and begins to track the order.
	 */
	public void submitToKitchen(Order order) {
		// draw unused items from pool
		Iterator<Item> cipiter = cancelItemPool.iterator();
		boolean stop = false;
		while (cipiter.hasNext() && !stop) {
			Item replacement = cipiter.next();
			for (int i = 0; i < order.getItems().size(); i++) {
				if (replacement.equals(order.getItems().get(i))) {
					order.getItems().set(i, replacement);
					cipiter.remove();
					break;
				}
				if (i == order.getItems().size() - 1) {
					stop = true;
				}
			}
		}
		activeOrders.add(order);
		kitchen.prepareOrder(order);
		order.setTimeKitchenSubmit(totalTime);
		// System.out.println("Setting TimeKitchenSubmit of Order.java from orderTracker.java~~ value of: "
		// + totalTime);
		order.setTimePlaced(totalTime);
	}

	/**
	 * Cancels the delivery of an order if possible. Cannot cancel if order is
	 * already being delivered.
	 * 
	 * @param order
	 *            - Order to cancel
	 * @return The success of the operation
	 */
	public boolean cancelOrder(Order order) {
		OrderStatus o = order.getStatus();
		if (o == OrderStatus.AWAITING_PICKUP || o == OrderStatus.DELIVERED
				|| o == OrderStatus.IN_TRANSIT) {
			return false;
		} else {
			activeOrders.remove(order);
			cancelItemPool.addAll(order.getItems());
			return true;
		}
	}

	/**
	 * Loads previous OrderTracker data from the data file.
	 * 
	 * @throws IOException
	 *             - Error in reading from file.
	 */
	@Override
	public void loadFromFile() throws IOException {
		File cfile = new File(ORDER_FILE);
		if (cfile.exists()) {
			Scanner scn = new Scanner(new FileInputStream(cfile));
			scn.useDelimiter(DataTracker.SEPARATOR);
			try {
				chefs = scn.nextInt();
				ovens = scn.nextInt();
				ovenSpace = scn.nextInt();
				cars = scn.nextInt();
				readyToStart = true;
			} catch (NoSuchElementException nse) {
				throw new IOException("Corrupted file: " + ORDER_FILE);
			}
			scn.close();
		} else {
			cfile.createNewFile();
		}
	}

	/**
	 * Saves current next order ID # to data file.
	 * 
	 * @throws IOException
	 *             - Error in writing to file.
	 */
	@Override
	public void saveToFile() throws IOException {
		File cfile = new File(ORDER_FILE);
		FileWriter fw = new FileWriter(cfile);
		fw.write(chefs + DataTracker.SEPARATOR);
		fw.write(ovens + DataTracker.SEPARATOR);
		fw.write(ovenSpace + DataTracker.SEPARATOR);
		fw.write(cars + DataTracker.SEPARATOR);
		fw.close();
	}

	/**
	 * Returns a list of active orders.
	 * 
	 * @return a list of active orders.
	 */
	@Override
	public List<Order> getData() {
		List<Order> allOrders = new ArrayList<Order>();
		allOrders.addAll(activeOrders);
		allOrders.addAll(deadOrders);
		return allOrders;
	}

	/**
	 * Adds an order to be tracked.
	 * 
	 * @param - data Order to be tracked.
	 */
	@Override
	public void addData(Order data) {
		submitToKitchen(data);
	}

	/**
	 * Returns the number of preparation chefs.
	 * 
	 * @return the chefs
	 */
	public int getChefs() {
		return chefs;
	}

	/**
	 * Returns the number of ovens.
	 * 
	 * @return the ovens
	 */
	public int getOvens() {
		return ovens;
	}

	/**
	 * Returns the space in each oven.
	 * 
	 * @return the ovenSpace
	 */
	public int getOvenSpace() {
		return ovenSpace;
	}

	/**
	 * Returns the number of delivery cars.
	 * 
	 * @return the cars
	 */
	public int getCars() {
		return cars;
	}

	/**
	 * Gets the total time passed by the system in the current day.
	 * 
	 * @return the total time.
	 */
	public int getTotalTime() {
		return totalTime;
	}

	/**
	 * Returns the static singleton instance of OrderTracker.
	 * 
	 * @return the static singleton instance of OrderTracker.
	 */
	public static OrderTracker getInstance() {
		return instance;
	}

	/**
	 * Formats a number of seconds into hh:mm:ss format.
	 * 
	 * @return the formatted time
	 */
	public static String formatTime(int secs) {
		int mins = (int) ((float) secs / 60f);
		int hours = (int) ((float) (mins) / 60f);
		int secsm = secs % 60;
		int minsm = mins % 60;
		String str = hours + "";
		if (minsm > 9) {
			str += ":" + minsm;
		} else {
			str += ":0" + minsm;
		}
		if (secsm > 9) {
			str += ":" + secsm;
		} else {
			str += ":0" + secsm;
		}
		return str;
	}
}
