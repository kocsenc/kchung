package domain;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * The Item class describes and updates a component of an order.
 * 
 * @author acc3863
 * 
 */
public class Item implements Cloneable {

	private String name;
	private int prepTime;
	private int cookTime;
	private int ovenSpace; // TODO: Should check if ovenSpace > Oven capacity
	private boolean isPrepared;
	private float price;
	private boolean hasToppings;
	private List<Topping> toppings;
	private boolean isPreparing;

	/**
	 * Secondary constructor for a default item with NO toppings. See primary
	 * constructor for more details on Item instantiation.
	 * 
	 * @param name
	 *            - The name
	 * @param prepTime
	 *            - Amount of time for a chef to prepare
	 * @param cookTime
	 *            - Amount of time needed to cook (0 if no cooking needed)
	 * @param ovenSpace
	 *            - Amount of space needed in an oven to cook (0 if no cooking
	 *            needed)
	 */
	public Item(String name, float price, int prepTime, int cookTime,
			int ovenSpace) {
		this(name, price, prepTime, cookTime, ovenSpace, false);
	}

	/**
	 * Primary constructor for item. Initializes an item with a name,
	 * preparation time, cook time how much oven space the item requires, and a
	 * boolean hasToppings.
	 * 
	 * @param name
	 *            - The name
	 * @param prepTime
	 *            - Amount of time for a chef to prepare
	 * @param cookTime
	 *            - Amount of time needed to cook (0 if no cooking needed)
	 * @param ovenSpace
	 *            - Amount of space needed in an oven to cook (0 if no cooking
	 *            needed)
	 * @param hasToppings
	 *            - True if this item can have toppings.
	 */
	public Item(String name, float price, int prepTime, int cookTime,
			int ovenSpace, boolean hasToppings) {
		this.name = name;
		this.price = price;
		this.cookTime = cookTime;
		this.prepTime = prepTime;
		this.ovenSpace = ovenSpace;
		this.isPrepared = false;
		this.isPreparing = false;
		this.hasToppings = hasToppings;
		this.toppings = new ArrayList<Topping>();
	}

	/**
	 * Constructs an instance of Item as a clone of another Item.
	 * 
	 * @param other
	 *            - Item to clone.
	 */
	private Item(Item other) {
		this(other.name, other.price, other.prepTime, other.cookTime,
				other.ovenSpace, other.hasToppings);
		for (Topping t : other.toppings) {
			this.toppings.add(t);
		}
	}

	/**
	 * Returns true if an item can have toppings.
	 * 
	 * @return true if an item can have toppings.
	 */
	public boolean hasToppings() {
		return hasToppings;
	}

	/**
	 * Returns a string describing this item in the following format.
	 * "Item: <name>, Prepared <isPrepared>"
	 * 
	 * @return String describing this item.
	 */
	@Override
	public String toString() {
		String ret = name + " " + getPriceString();
		if (hasToppings) {
			ret += " with ";
			for (int i = 0; i < toppings.size() - 1; i++) {
				ret += toppings.get(i).name + ", ";
			}
			ret += "and " + toppings.get(toppings.size() - 1).name;
		}
		return ret;
	}

	/**
	 * Query method to get the name of the item
	 * 
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns total price of the item.
	 * 
	 * @return the price.
	 */
	public float getPrice() {
		if (hasToppings) {
			float sum = price;
			for (Topping t : toppings) {
				sum += t.price;
			}
			return sum;
		} else {
			return price;
		}
	}

	/**
	 * Returns the price of the item formatted as a string.
	 * 
	 * @return the price of the item as a string.
	 */
	public String getPriceString() {
		return DecimalFormat.getCurrencyInstance().format(getPrice());
	}

	/**
	 * Query method to get the time required to prep
	 * 
	 * @return the prepTime
	 */
	public int getPrepTime() {
		return prepTime;
	}

	/**
	 * Query method to get the time required to cook
	 * 
	 * @return the cookTime
	 */
	public int getCookTime() {
		return cookTime;
	}

	/**
	 * Query method to get the oven capacity/space
	 * 
	 * @return the ovenSpace
	 */
	public int getOvenSpace() {
		return ovenSpace;
	}

	/**
	 * Query method to see if item is prepared
	 * 
	 * @return the isPrepared
	 */
	public boolean isPrepared() {
		return isPrepared;
	}

	/**
	 * Set the isPrepared boolean in the Item
	 * 
	 * @param isPrepared
	 */
	public void setPrepared(boolean isPrepared) {
		this.isPrepared = isPrepared;
	}

	/**
	 * Gets whether the item is in preparation.
	 * 
	 * @return true if the item is being prepared or already is prepared.
	 */
	public boolean isPreparing() {
		return isPreparing;
	}

	/**
	 * Sets if the item is in preparation
	 * 
	 * @param isPreparing
	 *            - true if the item is in preparation or is prepared.
	 */
	public void setPreparing(boolean isPreparing) {
		this.isPreparing = isPreparing;
	}

	/**
	 * Clones this item, returning an exact copy. Recommended to clone items
	 * before using them in orders.
	 * 
	 * @return The cloned item.
	 */
	@Override
	public Item clone() {
		return new Item(this);
	}

	/**
	 * Tests to see if this object equals another.
	 * 
	 * @return True if they are equal.
	 */
	@Override
	public boolean equals(Object o) {
		try {
			Item i = (Item) o;
			boolean toppingB = true;
			for (Topping t : this.getToppings()) {
				if (!i.getToppings().contains(t)) {
					toppingB = false;
					break;
				}
			}
			return i.cookTime == this.cookTime && i.name.equals(this.name)
					&& i.ovenSpace == this.ovenSpace
					&& i.prepTime == this.prepTime && i.price == this.price
					&& i.hasToppings == this.hasToppings && toppingB;
		} catch (ClassCastException cce) {
			return false;
		}
	}

	/**
	 * addTopping adds a new Topping class with given arguments.
	 * 
	 * @param name
	 * @param price
	 * @param side
	 */
	public void addTopping(String name, float price, TSide side) {
		if (hasToppings) {
			toppings.add(new Topping(name, price, side));
		}
	}

	/**
	 * Sets up enum for two sides of the pizza or the whole.
	 * 
	 * @author acc3863
	 * 
	 */
	public static enum TSide {
		LEFT("the left"), RIGHT("the right"), ALL("both sides.");
		private String name;

		private TSide(String name) {
			this.name = name;
		}

		@Override
		public String toString() {
			return name;
		}
	}

	/**
	 * @return toppings
	 */
	public List<Topping> getToppings() {
		return toppings;

	}

	/**
	 * Topping class gathers together the name, price and side delineations for
	 * use in various methods.
	 * 
	 * @author acc3863
	 * 
	 */
	public static class Topping {
		private String name;
		private float price;
		private TSide side;

		public Topping(String name, float price, TSide side) {
			this.name = name;
			this.price = price;
			this.side = side;
		}

		public float getToppingPrice() {
			return price;
		}

		public String getName() {
			return name;
		}

		public TSide getSide() {
			return side;
		}

		public String toString() {
			return name
					+ " "
					+ side.toString().substring(0, 1)
					+ side.toString().substring(1, side.toString().length())
							.toLowerCase();
		}

		public boolean equals(Topping o) {
			boolean sideB = (o.side == this.side)
					|| (o.side == TSide.LEFT && this.side == TSide.RIGHT)
					|| (o.side == TSide.RIGHT && this.side == TSide.LEFT);
			return this.name.equals(o.name) && this.price == o.price && sideB;
		}
	}
}
