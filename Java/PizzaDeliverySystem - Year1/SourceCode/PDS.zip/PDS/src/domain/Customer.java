package domain;

import java.text.ParseException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * The customer clsass embodies a customer customer who ordered from from the
 * delivery company.
 * 
 * @author acc3863
 * 
 */
public class Customer {

	private String name;
	private String phone;

	/**
	 * Constructs a customer object with a name and a phone number.
	 * 
	 * @param name
	 *            - The customer's name.
	 * @param phone
	 *            - The customer's phone number.
	 */
	public Customer(String name, String phone) {
		this.name = name;
		if (!phone.matches("((\\d(-?))?(\\d){3}(-?))?((\\d){3}-?(\\d){4})")) {
			throw new IllegalArgumentException("Bad phone number");
		}
		try {
			this.phone = parsePhone(phone);
		} catch (NoSuchElementException e) {
			this.phone = phone;
		}
	}

	/**
	 * Returns a string describing this customer in the following format.
	 * "<name> <phone #>"
	 * 
	 * @return String describing this customer.
	 */
	@Override
	public String toString() {
		return name + "(" + phone + ")";
	}

	/**
	 * @return the name of Customer
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the phone # of Customer
	 */
	public String getPhone() {
		return phone;
	}
	
	/**
	 * Parses a phone number into a standard format.
	 * @param scn - The scanner
	 * @param buf - The output buffer
	 * @throws NoSuchElementException - Thrown if parse fails.
	 */
	public static String parsePhone(String phone)
			throws NoSuchElementException {
		Scanner scn = new Scanner(new StringBuffer(phone).reverse().toString()).useDelimiter("");
		StringBuffer buf = new StringBuffer();
		parseFour(scn, buf);
		parseThree(scn, buf);
		if (scn.hasNext()) {
			parseThree(scn, buf);
		}
		if (scn.hasNext()) {
			parseOne(scn, buf);
		}
		return buf.reverse().toString();
	}

	/**
	 * Parses the last 4 digits of a phone number.
	 * @param scn - The scanner
	 * @param buf - The output buffer
	 * @throws NoSuchElementException - Thrown if parse fails.
	 */
	private static void parseFour(Scanner scn, StringBuffer buf)
			throws NoSuchElementException {
		buf.append(scn.next());
		buf.append(scn.next());
		buf.append(scn.next());
		buf.append(scn.next());
	}
	
	/**
	 * Parses the area code of a phone number.
	 * @param scn - The scanner
	 * @param buf - The output buffer
	 * @throws NoSuchElementException - Thrown if parse fails.
	 */
	private static void parseThree(Scanner scn, StringBuffer buf)
			throws NoSuchElementException {
		if (scn.hasNext("-")) {
			buf.append(scn.next());
		} else {
			buf.append("-");
		}
		buf.append(scn.next());// #
		buf.append(scn.next());// #
		buf.append(scn.next());// #
	}

	/**
	 * Parses the country code of a phone number.
	 * @param scn - The scanner
	 * @param buf - The output buffer
	 * @throws NoSuchElementException - Thrown if parse fails.
	 */
	private static void parseOne(Scanner scn, StringBuffer buf)
			throws NoSuchElementException {
		if (scn.hasNext("-")) {
			buf.append(scn.next());
		} else {
			buf.append("-");
		}
		buf.append(scn.next());
		if (scn.hasNext()) {
			throw new NoSuchElementException("Numbers found after country code");
		}
	}
}
