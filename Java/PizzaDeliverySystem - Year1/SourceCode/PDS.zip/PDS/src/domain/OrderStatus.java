package domain;


/**
 * The OrderStatus enum describes all possible states an order may be in during
 * its progress through the delivery process.
 * 
 * @author acc3863
 * 
 */
public enum OrderStatus {
	IN_PREP("In Preparation"), AWAITING_TRANSIT("Awaiting Transit"), IN_TRANSIT(
			"In Transit"), AWAITING_PICKUP("Awaiting Pickup"), DELIVERED(
			"Delivered");

	private String name;

	private OrderStatus(String name) {
		this.name = name;
	}

	/**
	 * Method that gets name, which is a status in this case.
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}
}
