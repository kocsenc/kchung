package domain;

import java.text.DecimalFormat;
import java.util.List;

import data.OrderTracker;
import data.StatisticsTracker;
import domain.Item;

/**
 * The Order class describes and provides access to all information regarding a
 * specific food order to be delivered to a customer.
 * 
 * @author acc3863
 * 
 */
public class Order {
	private List<Item> items;
	private Customer customer;
	private Destination destination;
	private OrderStatus status;
	private int id;
	private int estimate;
	private int timePlaced;
	private int timeDelivered;
	private int timeKitchenSubmit;
	private int timeKitchenStart;
	private int timeDeliverSubmit;
	private int timeDeliverStart;

	/**
	 * Constructs an order with a list of items on the order, along with a
	 * customer and location to deliver to.
	 * 
	 * Order Object holds: items, customer, destination. Provides information
	 * such as its own respective ID, and a status.
	 * 
	 * @param items
	 *            - Items to be prepared.
	 * @param customer
	 *            - Customer to deliver to.
	 * @param destination
	 *            - Location to deliver to.
	 */
	public Order(List<Item> items, Customer customer, Destination destination) {
		this.id = StatisticsTracker.getInstance().getNextOrderID();
		this.items = items;
		this.customer = customer;
		this.destination = destination;
		this.status = OrderStatus.IN_PREP;
		int maxItemTime = 0;
		for (Item i : items) {
			if (maxItemTime < i.getCookTime() + i.getPrepTime()) {
				maxItemTime = i.getCookTime() + i.getPrepTime();
			}
		}
		this.estimate = maxItemTime + destination.getCollectionTime()
				+ destination.getTimeTo();
		this.timePlaced = 0;
		this.timeDelivered = -1;
	}

	/**
	 * Returns the items within a specific order
	 * 
	 * @return the items
	 */
	public List<Item> getItems() {
		return items;
	}

	/**
	 * Returns the customer within a specific order
	 * 
	 * @return the customer
	 */
	public Customer getCustomer() {
		return customer;
	}

	/**
	 * Returns the destination within a specific order
	 * 
	 * @return the destination
	 */
	public Destination getDestination() {
		return destination;
	}

	/**
	 * Returns the status within a specific order
	 * 
	 * @return the status
	 */
	public OrderStatus getStatus() {
		return status;
	}

	/**
	 * Sets the order's status within a specific order
	 * 
	 * @param status
	 */
	public void setStatus(OrderStatus status) {
		this.status = status;
	}

	/**
	 * Returns the id of a specific order
	 * 
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * Returns the total price.
	 * 
	 * @return the total price.
	 */
	public double getPrice() {
		double sum = 0;
		for (Item i : items) {
			sum += i.getPrice();
		}
		return sum;
	}

	/**
	 * Returns the total price string.
	 * 
	 * @return the total price string.
	 */
	public String getPriceString() {
		return DecimalFormat.getCurrencyInstance().format(getPrice());
	}

	/**
	 * @return the estimate
	 */
	public int getEstimate() {
		return estimate;
	}

	/**
	 * @param estimate
	 *            the estimate to set
	 */
	public void setEstimate(int estimate) {
		this.estimate = estimate;
	}

	/**
	 * @return the timePlaced
	 */
	public int getTimePlaced() {
		return timePlaced;
	}

	/**
	 * @param timePlaced
	 *            the timePlaced to set
	 */
	public void setTimePlaced(int timePlaced) {
		this.timePlaced = timePlaced;
	}

	/**
	 * @return the timeDelivered
	 */
	public int getTimeDelivered() {
		return timeDelivered;
	}

	/**
	 * @param timeDelivered
	 *            the timeDelivered to set
	 */
	public void setTimeDelivered(int timeDelivered) {
		this.timeDelivered = timeDelivered;
	}

	/**
	 * getter for time of submitted to kitchen.
	 * 
	 * @return timeKitchenSubmit
	 */
	public int getTimeKitchenSubmit() {
		return timeKitchenSubmit;
	}

	/**
	 * setter for time submitted to kitchen.
	 * 
	 * @param timeKitchenSubmit
	 */
	public void setTimeKitchenSubmit(int timeKitchenSubmit) {
		this.timeKitchenSubmit = timeKitchenSubmit;
	}

	/**
	 * getter for time to start in kitchen
	 * 
	 * @return timeKitchenStart
	 */
	public int getTimeKitchenStart() {
		return timeKitchenStart;
	}

	/**
	 * setter for time to start in kitchen.
	 * 
	 * @param timeKitchenStart
	 */
	public void setTimeKitchenStart(int timeKitchenStart) {
		System.out.println("This is timeKitchenStart from Order.java (BEFORE)  " + this.timeKitchenStart);
		this.timeKitchenStart = timeKitchenStart;
		System.out.println("This is timeKitchenStart from Order.java (AFTER)  " + this.timeKitchenStart);
	}

	/**
	 * getter for time delivered submit
	 * 
	 * @return timeDeliverSubmit
	 */
	public int getTimeDeliverSubmit() {
		return timeDeliverSubmit;
	}

	/**
	 * setter for time deliver submit
	 * 
	 * @param timeDeliverSubmit
	 */
	public void setTimeDeliverSubmit(int timeDeliverSubmit) {
		this.timeDeliverSubmit = timeDeliverSubmit;
	}

	/**
	 * getter for starting time deliver
	 * 
	 * @return timeDeliverStart
	 */
	public int getTimeDeliverStart() {
		return timeDeliverStart;
	}

	/**
	 * setter for time starting delivery
	 * 
	 * @param timeDeliverStart
	 */
	public void setTimeDeliverStart(int timeDeliverStart) {
		this.timeDeliverStart = timeDeliverStart;
	}

	/**
	 * Returns a string representing the order.
	 * 
	 * @return a string representing the order.
	 */
	public String toString() {
		return String.format("Order #%1d to %2s at %3s", id,
				customer.toString(), destination.getName());
	}
}
